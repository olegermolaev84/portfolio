package tea.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Class-wrapper. To simulate work with System.console in Eclipse
 *
 */
public final class Console {
	public static String readLine(String prompt) {
        String line = null;
        java.io.Console c = System.console();
        
        if (c != null) {
        	line = c.readLine(prompt);
        } 
        else {
            System.out.print(prompt);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
            try {
                 line = bufferedReader.readLine();
            } catch (IOException e) { 
            	// Ignore   
            }
        }
        return line;
    }
}
