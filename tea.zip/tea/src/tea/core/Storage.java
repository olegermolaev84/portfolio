package tea.core;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.NavigableMap;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Class Storage is responsible for storying file content and some
 * additional file statistic and provides interface to access/change content.
 */
public class Storage {

	/** stores lines from the text file */
	private List<String> lines; 
	
	/**
	 *  stores map, where keys - all unique words from the text file
	 *  values - number of occurrences in the text
	 */
	private TreeMap<String, Integer> mapOfWords; 
	
	/** number of words in the text */
	private int numberOfWords;
	
	/** numbers of sings in the text. */
	private int numberOfSigns;
	
	private ListIterator<String> cursor;
	
	/**
	 * Structure to store current line content and its number.
	 */
	public static class CurrentLine{
		private String line = "";
		private int pos = -1; 
		
		/** 
		 * Returns content of the current line.
		 * 
		 * @return content of the current line.
		 */
		public String line() {return line;}
		
		/** 
		 * Returns number of the current line.
		 * 
		 * @return number of the current line.
		 */
		public int pos() {return pos;}
	}
	
	private CurrentLine currentLine;
	
	/** Turns all internal fields into the default state. */
	private void reset() {
		lines = null;
		numberOfWords = 0;
		numberOfSigns = 0;
		mapOfWords = new TreeMap<String, Integer>();
		cursor = null;
		currentLine = new CurrentLine();
	}
	
	Storage() {
		reset();
	}

	/**
	 * Reads content of the given file and saves it in the internal structure of the Storage class.
	 * Moves cursor to the first line if it presents. 
	 * 
	 * @param file - file to read.
	 * @param for_read_only - indicates whether changing of the file allowed or not.
	 * @throws IOException throws if any error occurred while file reading.
	 */
	public void readFile(Path file, boolean for_read_only) throws IOException {
		// We may work before with another file. So clean the storage.
		reset();
		
		if (for_read_only){
			lines = new ArrayList<String>();
		}
		else {
			lines = new LinkedList<String>();
		}
		
		try (Scanner file_scanner = new Scanner (file)){
			while(file_scanner.hasNextLine()) {
				String line = file_scanner.nextLine();
				lines.add(line);
				updateSupplimentaryFields(line, true);
			}
		}
		
		setCursor(0); 
	}
	
	/**
	 * Removes line with denoted index from the text. Moves cursor to the next line after removed 
	 * or to the previous one if removed line was last.
	 * 
	 * @param index  position of line to be removed.
	 * @return removed line content.
	 *                
	 * @throws ArrayIndexOutOfBoundsException if index is negative or more or equals then number of lines in the text file.
	 */
	public String removeLine(int index) throws ArrayIndexOutOfBoundsException {
		if(index < 0 || index >= lines.size()) {
			throw new ArrayIndexOutOfBoundsException("index = " + index);
		}
		
		cursor = lines.listIterator(index);
		String removedLine = cursor.next();
		updateSupplimentaryFields(removedLine, false);
		cursor.remove();
		if(lines.size() == 0) {
			setCursor(0);
		}
		else if (index == lines.size()) {
			setCursor(index - 1);
		}
		else {
			setCursor(index);
		}
		
		return removedLine;
	}
	
	/**
	 * Inserts new line of text before the the specified position of the iterator. Sets cursor to the added line.
	 * 
	 * @param line  line to be inserted.
	 * @param index  position of iterator.
	 *                
	 * @throws ArrayIndexOutOfBoundsException if index is negative or more then number of lines in the text file.
	 * 
	 */
	public void addLine(String line, int index) throws ArrayIndexOutOfBoundsException {
		if(index < 0 || index > lines.size()) {
			throw new ArrayIndexOutOfBoundsException("index = " + index);
		}
		
		cursor = lines.listIterator(index);
		cursor.add(line);
		updateSupplimentaryFields(line, true);
		setCursor(index);
	}
	
	/**
	 * Replaces all lines which indexes are matched indexes in the denoted map.
	 * Cursor is not changed.
	 * 
	 * @param replacementStrings - sorted Map with keys - indexes of lines to be replaced, value - replacement Strings.  
	 */
	public void replaceLines(NavigableMap<Integer, String> replacementStrings) {
		if(lines.size() == 0 || replacementStrings.size() == 0) {
			return;
		}
		
		if (replacementStrings.firstKey() < 0 || replacementStrings.lastKey() >= lines.size()) {
			throw new ArrayIndexOutOfBoundsException("lines last index = " + (lines.size() - 1) + ". given set bounds ["
					+ replacementStrings.firstKey() + ", " + replacementStrings.lastKey() + "]");
		}
		
		int cursorPosition = (currentLine.pos == -1?0:currentLine.pos);
		setCursor(replacementStrings.firstKey());
		
		Set<Integer> linesNumbers = replacementStrings.keySet();
		
		for(int i = replacementStrings.firstKey(); i <= replacementStrings.lastKey(); i++){
			if(linesNumbers.contains(currentLine.pos)) {
				updateSupplimentaryFields(currentLine.line, false);
				updateSupplimentaryFields(replacementStrings.get(i), true);
				
				cursor.set(replacementStrings.get(i));
			}
			next();
		}
		setCursor(cursorPosition);
	}
	
	/**
	 * Updates supplementary fields which are responsible for storing statistic information about 
	 * the text file.
	 *  
	 * @param line line in the text file which is going to be added or removed.
	 * @param lineIsAdded <code>true</code> line is going to be added, 
	 *                    <code>false</code> line is going to be removed.
	 */
	private void updateSupplimentaryFields(String line, boolean lineIsAdded) {
		// numberOfSigns
		if(lineIsAdded) {
			numberOfSigns += line.codePointCount(0, line.length());
		}
		else {
			numberOfSigns -= line.codePointCount(0, line.length());
		}
			
		
		String[] words = line.split("\\W");// \W - not word characters
		for (String word : words) {
			if (word.isBlank()) {
				continue;
			}
			
			// update numberOfWords
			if(lineIsAdded) {
				numberOfWords++;
			}
			else {
				numberOfWords--;
			}

			// update mapOfWords
			if(lineIsAdded) {
				mapOfWords.merge(word, 1, (oldValue, value) -> oldValue + value);
			}
			else {
				Integer value = mapOfWords.get(word);
				assert value != null: "expected word: " + word + " is not found in the mapOfWords map";
				if(value == 1) {
					mapOfWords.remove(word);
				}
				else {
					mapOfWords.put(word, value - 1);
				}
			}
		}
	}
	
	/** 
	 * Returns numbers of sings in the text.
	 * 
	 * @return numbers of sings in the text.
	 */
	public int getNumberOfSigns() {return numberOfSigns;}
	
	/** 
	 * Returns number of words in the text.
	 * 
	 * @return number of words in the text.
	 */
	public int getNumberOfWords() {	return numberOfWords;}
	
	/** 
	 * Returns number of unique words in the text.
	 * 
	 * @return number of unique words in the text.
	 */
	public int getNumberOfUniqWords() {return mapOfWords.size();}
	
	/** 
	 * Returns number of lines in the text.
	 * 
	 * @return number of lines in the text.
	 */
	public int getNumberOfLines() { return lines.size();}
	
	/**
	 * Returns unmodifiable view of List with lines from the text.
	 *  
	 * @return unmodifiable view of List with lines from the text.
	 */
	public List<String> getLines() {return Collections.unmodifiableList(lines);	}
	
	/** 
	 * Returns unmodifiable view of unique map of words from the text.
	 * 
	 * @return unmodifiable view of unique map of words from the text.
	 */
	public SortedMap<String, Integer> getMapOfWords(){return Collections.unmodifiableSortedMap(mapOfWords);}

	/**
	 * Returns current line.
	 * 
	 * @return structure which has a pair of line and its position in the text.
	 */
	public CurrentLine getCurrentLine() {
		return currentLine; 
	}
	
	/**
	 * Moves cursor to the next line and updates the currentLine structure.
	 * If the cursor is already in the EOF position, the currentLine structure remains the same.
	 * 
	 * @return <code>false</code> if cursor already is at EOF.
	 */
	public boolean next() {
		// Because of position of the iterator is between two elements the next() method 
		// will set currentLine to the same value if the previous() method has been just called. 
		// In this case we should call next() method twice.
		int currentPos = currentLine.pos;
					
		if(cursor.hasNext()) {
			currentLine.pos = cursor.nextIndex();
			currentLine.line = cursor.next();
			if(currentPos == currentLine.pos)
			{
				return next();
			}
			return true;
		}	
		return false;
	}
	
	/**
	 * Moves cursor to the previous line and updates the currentLine structure.
	 * If the cursor is already in the BOF position, the currentLine structure remains the same.
	 * 
	 * @return <code>false</code> if cursor already is at BOF.
	 */
	public boolean previous() {
		if(cursor.hasPrevious()) {
			// Because of position of the iterator is between two elements the previous() method 
			// will set currentLine to the same value if the next() method has been just called. 
			// In this case we should call previous() method twice.
			int currentPos = currentLine.pos;
			
			currentLine.pos = cursor.previousIndex();
			currentLine.line = cursor.previous();
			if(currentPos == currentLine.pos)
			{
				return previous();
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Sets cursor to the given index.
	 * 
	 * @param index - position where the cursor is to be set.
	 * @throws ArrayIndexOutOfBoundsException if index is negative or more/equals number of lines in the text file.
	 */
	public void setCursor(int index) throws ArrayIndexOutOfBoundsException {
		if(index < 0 || index > lines.size()) {
			throw new ArrayIndexOutOfBoundsException("out of bounds index = " + index);
		}
		
		cursor = lines.listIterator(index);
		currentLine = new CurrentLine(); // need to clean for case of lines.isEmpty() = true
		next();
	}
}
