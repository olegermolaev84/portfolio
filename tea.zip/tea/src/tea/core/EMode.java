package tea.core;

/**
 * Represents the mode of the program.
 */
public enum EMode {
	MENU("menu> "), READ("read> "), UPDATE("update> ");

	private String prompt;

	private EMode(String prompt) {
		this.prompt = prompt;
	}

	/**
	 * Returns prompt to be printed to console to show the current mode.
	 * 
	 * @return string with prompt 
	 */
	public String toString() {
		return prompt;
	}
}
