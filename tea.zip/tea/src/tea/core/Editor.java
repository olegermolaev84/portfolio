package tea.core;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;

import tea.commands.ICommand;

/**
 * Implements the editor:<br>
 * 1. Stores text file content in the Storage class object. <br>
 * 2. Stores some additional information, which specifies the current state of 
 * editor (e.g. buffer, list on undo/redo commands, file name, etc.). <br>
 * 3. Provides necessary interface for the commands.
 */
public class Editor {

	/** Path object wired with the currently editing file. */
	private       Path     file;
	
	private final Storage  storage;
	
	/** Path object wired with the current directory of the program. */
	private Path directory;
	
	/** Current mode of the editor.  */
	private EMode mode;
	
	/**
	 * flag which shows whether the program should exit the program after the current command is processed.
	 */
	private boolean exitTheProgram;
	
	private final ArrayDeque<ICommand> undo;
	private final ArrayDeque<ICommand> redo;
	
	/** String copied by either <code>copy</code> or by <code>remove</code> command.*/
	private String buffer = "";
	
	public Editor() throws IOException {
		file = null;
		storage = new Storage();
		directory = Paths.get(".").toRealPath();
		mode = EMode.MENU;
		exitTheProgram = false;
		undo = new ArrayDeque<ICommand>();
		redo = new ArrayDeque<ICommand>();
	}
	
	/** 
	 * Sets path object wired with the currently editing file.
	 * 
	 * @param file - Path wired with the currently editing file.
	 */
	public void setFile(Path file) {this.file = file;}
	
	/** 
	 * Returns path object wired with the currently editing file.
	 * 
	 * @return path object wired with the currently editing file
	 */
	public Path getFile() {return file;}
	
	/** 
	 * Returns Storage object with the file content.
	 * 
	 * @return Storage object with the file content
	 */
	public Storage getStorage() {return storage;}
	
	/** 
	 * Sets path object wired with the current directory of the program.
	 * 
	 * @param directory - path object wired with the current directory of the program.
	 */
	public void setDirectory(Path directory) {this.directory = directory.normalize();}
	
	/** 
	 * Returns path object wired with the current directory of the program.
	 * 
	 * @return path object wired with the current directory of the program.
	 */
	public Path getDirecory() { return directory;}
	
	/** 
	 * Changes the mode of the editor to the given.
	 * 
	 * @param mode EMode constant to set.
	 */
	public void setMode(EMode mode) {this.mode = mode;}
	
	/** 
	 * Returns the current mode of the editor.
	 * 
	 * @return current mode of the editor
	 */
	public EMode getMode() { return mode;}
	
	/** 
	 * Sets special flag, which shows what the program should exit.
	 */
	public void setExit() { exitTheProgram = true;}
	
	/** 
	 * Returns <code>true</code> if the program should exit. 
	 * 
	 * @return <code>true</code> if the program should exit, otherwise <code>false</code>.
	 */
	public boolean getExit() {return exitTheProgram;}
	
	/** 
	 * Returns <code>true</code> if the text file content changed.
	 * 
	 * @return <code>true</code> if the text file content changed, otherwise <code>false</code>.
	 */
	public boolean isFileChanged() {return undo.size() > 0;	}
	
	/** 
	 * Returns copied/removed line. 
	 * 
	 * @return copied/removed line or empty string if no lines are placed into buffer.
	 */
	public String getBuffer() {return buffer;}
	
	/**
	 * Sets buffer.
	 * 
	 * @param buffer - string content to be placed into the buffer.
	 */
	public void setBuffer(String buffer) {
		this.buffer = buffer;
	}
	
	/** 
	 * Returns undo queue of commands.
	 * 
	 * @return undo queue.
	 */
	public ArrayDeque<ICommand> getUndoQueue() {return undo;} 
	
	/** 
	 * Returns redo queue of commands. 
	 * 
	 * @return redo queue.
	 */
	public ArrayDeque<ICommand> getRedoQueue() {return redo;} 
}
