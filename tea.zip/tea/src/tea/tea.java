
package tea;

import java.io.IOException;
import java.util.Objects;

import tea.commands.ICommand;
import tea.core.Editor;
import tea.tools.Console;

/**
 * Parses command line arguments and starts processing.
 *
 */
class tea {

	private static int OFFSET_IN_HELP_MESSAGE_1 = 5;
	private static int OFFSET_IN_HELP_MESSAGE_2 = 10;
	
	private static String helpMessage =
	"=============================================================================\n"+
	"                         tea command line arguments:\n"+
	"=============================================================================\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "Without any arguments.\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Switches the program to the menu mode.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "-c <Filename>\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Creates new file for editing. Switches the program to the update mode.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "-u <Filename>\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Opens the file for updating. Switches the program to the update mode.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "-r <Filename>\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Opens the file for reading. Switches the program to the read mode.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "-help\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Prints how to use the program and exits.\n\n"+
	"=============================================================================\n"+
	"                         tea modes:\n"+
	"=============================================================================\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "Menu\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Allows to choose a file to be read/updated/created.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "Read\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Allows to read a file without alteration.\n"
	+ " ".repeat(OFFSET_IN_HELP_MESSAGE_1) + "Update\n"
		+ " ".repeat(OFFSET_IN_HELP_MESSAGE_2) + "Allows to update a file.";
	
	public static void main(String[] args) throws IOException {
		parseArguments(args);
	}

	/**
	 * Parses command line arguments and if they are correct runs the program in the appropriate mode.
	 * @param args - command line arguments.
	 * @throws IOException in case of unexpected IO problems.
	 */
	private static void parseArguments(String[] args) throws IOException {
		Editor editor = new Editor();
		
		// -help
		if(args.length == 1 && args[0].equalsIgnoreCase("-help")) {
			System.out.println(helpMessage);
		}
		
		// -c <File name>
		else if(args.length == 2 && args[0].equalsIgnoreCase("-c")) {
			run(ICommand.create("create " + args[1], editor), editor);
		}
		
		// -u <File name>
		else if (args.length == 2 && args[0].equalsIgnoreCase("-u")) {
			run(ICommand.create("update " + args[1], editor), editor);
		}
		
		// -r <File name>
		else if (args.length == 2 && args[0].equalsIgnoreCase("-r")) {
			run(ICommand.create("read " + args[1], editor), editor);
		}
		
		// No arguments
		else if (args.length == 0) {
			run(null, editor);
		}
		
		// unexpected arguments
		else {
			System.out.println("Unexpected arguments: " + String.join(" ", args));
			System.out.println();
			System.out.println(helpMessage);
		}
	}
	
	/**
	 * Requests commands from the customer and processes them till <code>exit</code> command entered
	 * or critical error occurred.
	 * @param firstCommand - first command to be processed which denoted by user via command line arguments.
	 * @param editor - not null Editor class object.
	 */
	private static void run(ICommand firstCommand, Editor editor) {
		while(!editor.getExit()) {
			ICommand command;
			
			if(firstCommand == null) {
				String request = Console.readLine(editor.getMode().toString());
				if(Objects.isNull(request)) {
					editor.setExit();
					continue;
				}
				else if(request.isBlank()) {
					continue;
				}
				command = ICommand.create(request, editor);
			}
			else {
				command = firstCommand;
				firstCommand = null;
			}
			
			if(command == null || !command.supportedInMode(editor.getMode())) {
				System.out.println("Unsupported command entered. Please type \"help\" to display applicable commands.");
			}
			else if(command.initialize()) {
				command.perform();
			}
			else {
				System.out.println(command.getErrorMessage());
			}
		}
	}
}
