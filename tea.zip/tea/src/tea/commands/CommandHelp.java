package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>help</code> command.
 *
 */
class CommandHelp extends AbstractCommand {
	
	/** list of supported command variations. */
	private enum ActionToPerform {
		VERBOSE, LIST_OF_COMMANDS;
	}

	private ActionToPerform actionToPerform;

	CommandHelp(Editor editor, Parser parser) { 
		super(editor, parser);
	}

	/**
	 * Applicable arguments:<br>
	 * No arguments<br>
	 * <code>verbose</code><br>
	 * <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.isNoSpecialArgs()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		if(parser.getArgs().length == 0) {
			actionToPerform = ActionToPerform.LIST_OF_COMMANDS;
			return parametersSetCorrectly = true;
		}
		else if(parser.getArgs().length == 1 && parser.getArgs()[0].equalsIgnoreCase("verbose")) {
			actionToPerform = ActionToPerform.VERBOSE;
			return parametersSetCorrectly = true;
		}
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
	}

	/**
	 * Prints a list of applicable for the current mode commands.<br>
	 * OR<br>
	 * Prints all applicable for the current mode commands in details.<br>
	 */
	@Override
	protected void performUniqWork() {

		var supported_ecommands = ICommand.getSupportedCommandsForMode(editor.getMode());
		
		StringBuilder result = new StringBuilder();
		
		for (ESupportedCommands e_command: supported_ecommands) {
			if(actionToPerform == ActionToPerform.VERBOSE) {
				result.append(ICommand.create(e_command.toString(), editor).getHelpMessage() + "\n");
			}
			else {
				if(result.length() == 0) {
					result.append("supported commands:\n");
				}
				else {
					result.append(", ");
				}
				result.append(e_command.toString().toLowerCase());
			}
		}
		
		printStream.print(result.toString());
		
		if(actionToPerform != ActionToPerform.VERBOSE) {
			printStream.println("\n\nPlease enther \"<command name> ?\" - to get more verbose information about the command.");
			printStream.println("or \"help verbose\" - to print verbose information about all supported commands.");
		}
	}

	@Override
	public String getHelpMessage() {
		return "help\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Prints a list of applicable for the current mode commands.\n" 
	         + "help verbose\n"
	            + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Prints all applicable for the current mode commands in details.\n";
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return true;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
