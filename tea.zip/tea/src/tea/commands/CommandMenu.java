package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>menu</code> command.
 *
 */
class CommandMenu extends CommandExit {

	public CommandMenu(Editor editor, Parser parser) {
		super(editor, parser);
	}

	@Override
	public String getHelpMessage() {
		return "menu\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Closes the file and switches to menu mode.\n";
	}

	/** Closes the file and switches to menu mode. */
	@Override
	protected void performUniqWork() {
		saveChanges();
		editor.getRedoQueue().clear();
		editor.getUndoQueue().clear();
		editor.setMode(EMode.MENU);
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
