package tea.commands;

import java.nio.file.Files;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>read</code> command.
 */
class CommandRead extends AbstractCommandWorkingWithPaths {
	
	CommandRead(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments: <br>
	 * <code>Filename</code> - string with a name of an existent file with enough
	 * permissions to read the file.<br>
	 * <b>?</b>
	 */
	@Override
	protected boolean uniqInitialization() {
		if(!Files.exists(path)) {
			setErrorMessage("File: " + path.normalize() + " not found");
			return parametersSetCorrectly = false;
		}
		else if(Files.isDirectory(path)){
			setErrorMessage("File: " + path.normalize() + " is directory");
			return parametersSetCorrectly = false;
		}
		else if(!Files.isReadable(path)) {
			setErrorMessage("Cannot open file: " + path.normalize() + " for reading");
			return parametersSetCorrectly = false;
		}
		
		return parametersSetCorrectly = true;
	}

	/**
	 * Reads content of the file and saves it to the Storage.
	 */
	@Override
	protected void performUniqWork() {

		editor.setFile(path);
		readFile(true);
		editor.setMode(EMode.READ);
	}

	@Override
	public String getHelpMessage() {
		return "read <filename>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Opens the file for reading and switches to the read mode.\n";
	}
}
