package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>remove</code> command.
 *
 */
class CommandRemove extends AbstractCommand {

	/** For undo command: index where the line is to be inserted. */
	private int removedIndex = -1;
	
	/** For undo command: removed line content. */
	private String removedLine = "";
	
	CommandRemove(Editor editor, Parser parser) {
		super(editor, parser);
	}
	

	/**
	 * Applicable arguments: <br>
	 * Single number.<br>
	 * <b>?</b>  
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.isNoSpecialArgs()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		if(parser.getArgs().length ==  1
				&& Parser.isInteger(parser.getArgs()[0]))
		{
			if(editor.getStorage().getNumberOfLines() == 0) {
				setErrorMessage("file is empty");
				return parametersSetCorrectly = false;
			}
			else if(Integer.valueOf(parser.getArgs()[0]) < 0
					|| Integer.valueOf(parser.getArgs()[0]) >= editor.getStorage().getNumberOfLines()) {
				setErrorMessage("Expected correct index in bound from 0 to " + (editor.getStorage().getNumberOfLines() - 1));
				return parametersSetCorrectly = false;	
			}
			return parametersSetCorrectly = true;
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;			
		}
	}

	/**
	 *  Removes the current line and moves it to the buffer.
	 */
	@Override
	protected void performUniqWork() {
		removedIndex = Integer.valueOf(parser.getArgs()[0]);
		removedLine = editor.getStorage().removeLine(removedIndex);
		editor.setBuffer(removedLine);
	}

	@Override
	public String getHelpMessage() {
		return "remove <num>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Removes line with index <num>. Sets cursor to the next line. The removed line is placed into the buffer.\n";
	}

	@Override
	public boolean contentChanged() {
		return removedIndex >= 0;
	}

	@Override
	public void undo() {
		editor.getStorage().addLine(removedLine, removedIndex);
	}
	
	@Override 
	public void redo() {
		editor.getStorage().removeLine(removedIndex);
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
