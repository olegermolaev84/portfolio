package tea.commands;

import tea.core.EMode;
import tea.core.Editor;
import tea.tools.Console;

/**
 * Implements <code>search</code> command.
 *
 */
class CommandSearch extends AbstractCommand {

	protected boolean search_ci = false;
	protected boolean search_whole = false;
	
	CommandSearch(Editor editor, Parser parser) {
		super(editor, parser);
	}
	
	/**
	 * Applicable arguments:<br>
	 * <code>phrase</code> "phrase"<br>
	 * <code>ci phrase</code> "phrase" <br>
	 * <code>whole phrase </code> "phrase" <br>
	 * <code>ci whole phrase </code> "phrase"<br>
	 * <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(parser.getPhrase().isBlank()) {
			setErrorMessage("Phrase to search is not specified.");
			return parametersSetCorrectly = false;
		}
		
		if(parser.getFrom() >= 0) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		return initializeSearchMode();
	}
	
	/** 
	 * Initializes search mode. It is common initializing block for both search and replace commands.
	 * @return <code>true</code> if arguments are applicable, otherwise <code>false</code>.
	 */
	protected final boolean initializeSearchMode() {
		// phrase "phrase"
		if(parser.getArgs().length == 1) {
			return parametersSetCorrectly = true;
		}
		
		//ci phrase "phrase"
		else if (parser.getArgs().length == 2
				&&parser.getArgs()[0].equalsIgnoreCase("ci"))
		{
			search_ci = true;
			return parametersSetCorrectly = true;
		}
		
		//whole phrase "phrase"
		else if (parser.getArgs().length == 2 
				&& parser.getArgs()[0].equalsIgnoreCase("whole"))
		{
			if(parser.isPhraseOfSingleWord()) {
				search_whole = true;
				return parametersSetCorrectly = true;
			}
			else {
				setErrorMessage("If the whole key word denoted, then the search phrase must consist of a single word.");
				return parametersSetCorrectly = false;
			}
		}
		
		//ci whole phrase "phrase"
		else if (parser.getArgs().length == 3) 
		{	
			for(String arg: parser.getArgs()) {
				if(arg.equalsIgnoreCase("ci")) {
					search_ci = true;
				}
				else if (arg.equalsIgnoreCase("whole")) {
					search_whole = true;
				}
			}
			
			if(!search_ci || !search_whole) {
				setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
				return parametersSetCorrectly = false;
			}
			else if(!parser.isPhraseOfSingleWord()) {
				setErrorMessage("If the whole key word denoted, then the search phrase must consist of a single word.");
				return parametersSetCorrectly = false;	
			}
			
			return parametersSetCorrectly = true;
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}	
	}
	
	/** 
	 * Checks whether the current line contains searched phrase.  
	 * 
	 * @return <code>true</code> if the current line contains searched phrase, otherwise returns <code>false</code>.
	 */
	protected final boolean currentLineHasSearchPhrase() {
		String line = editor.getStorage().getCurrentLine().line();
		String phrase = parser.getPhrase();

		if (search_ci) {
			line = line.toUpperCase();
			phrase = phrase.toUpperCase();
		}

		int index = line.indexOf(phrase);
		if (index >= 0) {
			if (!search_whole) {
				return true;

			} else {
				String[] words = line.split("\\s"); // \s - any whitespace characters

				for (String s : words) {
					if (s.equals(phrase)) {
						return true;
					}
				}
			}
		}

		return false;
	}
	
	
	/** 
	 * Shows found lines in portion by NUM_LINES_TO_BE_PRINTED_AT_ONCE lines. 
	 */ 
	@Override
	protected void performUniqWork() {
		// save cursor position in order to reestablish it later.
		int cursorPosition = editor.getStorage().getCurrentLine().pos();
		
		editor.getStorage().setCursor(0);
		
		int numberOfLinesPrinted = 0;
		
		do{
			if(!currentLineHasSearchPhrase()){
				continue;
			}
			
			if (numberOfLinesPrinted == NUM_LINES_TO_BE_PRINTED_AT_ONCE) {
				// user should press Enter to show another portion of lines
				// or STOP and press Enter to stop showing
				if(Console.readLine(". . . . . >").strip().equalsIgnoreCase("stop")) {
					break;
				}
				else {
					numberOfLinesPrinted = 0;
				}
			}
		
			printStream.println("<" + editor.getStorage().getCurrentLine().pos() + "> " + editor.getStorage().getCurrentLine().line());
			numberOfLinesPrinted++;
		}while(editor.getStorage().next());
		
		editor.getStorage().setCursor(cursorPosition == -1? 0: cursorPosition);
	}
	
	@Override
	public String getHelpMessage() {
		return "search [ci] [whole] phrase <phrase>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Searches and shows lines which contains the specified phrase.\n" 
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "If <whole> key word specified, then shows only lines which contain exact the same word as in <phrase>.\n" 
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "<whole> option is applicable for single word phrase only. \n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "<ci> option allows to find lines case-insensitively.\n"
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Lines are shown in portions of "+ NUM_LINES_TO_BE_PRINTED_AT_ONCE + " lines. \n"
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "To print the next portion press the Enter button. To stop printing type STOP and press Enter.\n";
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
