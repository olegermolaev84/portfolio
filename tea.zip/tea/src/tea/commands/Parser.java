package tea.commands;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Parses commands given by user.
 */
class Parser {
	/** command name*/ 
	private String commandName = "";
	
	/** not parsed args (rest of line after the command name)*/ 
	private String notParsedArgs = ""; 
	
	/** temporary variable for internal purposes only*/
	private String stringToParse = "";
	
	/** array of parsed args (phrase is not parsed and stored separately)*/
	private String[] args = new String[0];
	
	/** rest of line after the key word "phrase"*/
	private String phrase = ""; 

	/** "from" number of the numbers' range denoted by expression "from"-"to" */  
	private int from = -1;
	
	/** "to" number of the numbers' range denoted by expression "from"-"to" */
	private int to = -1;
	
	/**
	 * Constructor.
	 * 
	 * @param command - initial command given by user.
	 */
	Parser(String command) {
		parseCommandName(command);
		parsePhrase();
		parseFromTo();
		parseOtherTokens();
	}
	
	/** Returns command name.
	 * 
	 * @return string with command name.
	 */
	public String getCommandName() {return commandName;}
		
	/**  
	 * Returns args of the command as a single string (rest of the command after the command name).
	 * 
	 * @return args of the command as a single string
	 */
	public String getNotParsedArgs() {return notParsedArgs;} 
		
	/**  
	 * Returns parsed args as an array of strings.
	 * 
	 * @return parsed args as an array of strings.
	 */
	public String[] getArgs() {return args;}
		
	/**
	 * Returns rest of the command after the key word "phrase". 
	 * If the key word not found, then returns empty string.
	 * 
	 * @return rest of the command after the key word "phrase" or empty string
	 */
	public String getPhrase() {return phrase;} 

	/**
	 * Returns "from" number of the "from-to" range. If the range not found, then returns -1.
	 * 
	 * @return "from" number of the "from-to" range or -1
	 */
	public int getFrom() {return from;}
		
	/**
	 * Returns "to" number of the "from-to" range. If the range not found, then returns -1.
	 * 
	 * @return "to" number of the "from-to" range or -1
	 */
	public int getTo() {return to;}
	
	/**
	 * Checks whether the command args have some special elements like "from-to" or "phrase".
	 * 
	 * @return <code>true</code> if no special elements found.
	 */
	public boolean isNoSpecialArgs() {
		return to == -1 && from == -1 && phrase.equals("");
	}
	
	/**
	 * Checks whether the denoted string contains only digits.
	 * 
	 * @param argToCheck string to check.
	 * @return <code>true</code> if the denoted string has only digits.
	 */
	public static boolean isInteger(String argToCheck)
	{
		try {
			Integer.valueOf(argToCheck);
			return true;
		}
		catch (NumberFormatException e) {
			return false;
		}
	}
	
	/**
	 * Parses the command name.
	 * 
	 * @param command  - string with command name and its args to be parsed. 
	 */
	private void parseCommandName(String command) {
		if (command.isBlank()) return;
		
		String[] res = command.split("\\s", 2); // \s - any whitespace characters
		commandName = res[0].toLowerCase();
	
		if (res.length == 2) {
			notParsedArgs = stringToParse = res[1];
		}
	}
	
	/** Looks for the key word "phrase". If found then gets a phrase after the key word. */
	private void parsePhrase() {
		int index = stringToParse.toLowerCase().indexOf("phrase");
		
		if(index == -1) { //<phrase> key word not found
			return;
		}
		
		phrase = stringToParse.substring(index+6).strip();
		stringToParse = stringToParse.substring(0, index+6);
	}
	
	/** Looks for a number range denoted in format "from" - "to". If found then parses the numbers. */
	private void parseFromTo() {
		for(int start = 0; start < stringToParse.length(); start++) {
			int end = isFirstIndexOfFrom(start);
			if(end != -1) {
				setFromTo(stringToParse.substring(start, end+1));
				stringToParse = stringToParse.substring(0, start) + stringToParse.substring(end+1);
			}
		}
	}
	
	/**
	 * Sets Parser.from and Parser.to from the given string with "from" - "to" range encoded.
	 * @param fromTo string with "from" - "to" range encoded.
	 */
	private void setFromTo(String fromTo) {
		boolean fromFound = false;
		
		for(int i = 0; i < fromTo.length();i++) {
			if(Character.isDigit(fromTo.charAt(i))) {
				if(!fromFound) {
					continue;
				}
				else {
					this.to = Integer.valueOf(fromTo.substring(i));
					break;
				}
			}
			else if(Character.isWhitespace(fromTo.charAt(i)) || fromTo.charAt(i) == '-') {
				if(!fromFound) {
					fromFound = true;
					this.from = Integer.valueOf(fromTo.substring(0, i));
				}
				continue;
			}
		}
	}
	
	/**
	 * Checks whether on the given index presents the first symbol of "from" number 
	 * from the "from" - "to" range .
	 *
	 * @param index index for analyzing.
	 * @return <code>-1</code> - if it is not first symbol of "from" number,<br>
	 *          otherwise returns <code>index</code> of last digit in the "to" number. 
	 */
	private int isFirstIndexOfFrom(int index) {
		// will be true if
		// symbol in the given position is numeral 
		// AND
		// the previous symbol is absent OR whitespace 
		// AND
		// after this symbol may be from 0 to several numerals AND after them from 0 to several whitespace chars
		// AND after them one single '-' sign AND after it from 0 to several whitespace chars 
		// AND after them index of first numeral of "to" number  
		if(!Character.isDigit(stringToParse.charAt(index))) {
			return -1;
		}
		
		if(index > 0 && (!Character.isWhitespace(stringToParse.charAt(index - 1)))) {
			return -1;
		}
		
		boolean firstNotNumeralFound = false;
		boolean delimiterFound = false;
		while(index < stringToParse.length() - 1) {
			index++;
			if(Character.isDigit(stringToParse.charAt(index)) && !firstNotNumeralFound){
				continue;
			}
			else if(Character.isWhitespace(stringToParse.charAt(index))){
				firstNotNumeralFound = true;
				continue;
			}
			else if(stringToParse.charAt(index) == '-') {
				if(delimiterFound) { 
					// second delimiter is not allowed
					return -1;
				}
				delimiterFound = true;
				firstNotNumeralFound = true;
				continue;
			}
			return delimiterFound? isFirstIndexOfTo(index):-1;
		}
		return -1;
	}

	/**
	 * Checks whether on the given index presents the first symbol of "to" number from the "from" - "to" range 
	 *
	 * @param index index for analyzing.
	 * @return <code>-1</code> - if it is not first symbol of "to" number,<br>
	 *         otherwise returns <code>index</code> of last digit in the "to" number.  
	 */
	private int isFirstIndexOfTo(int index) {
		// will be true if
		// symbol in the given position is numeral 
		// AND
		// the previous symbol presents AND either whitespace OR "-" 
		// AND
		// after this symbol may be several numerals AND after them whitespace OR end of string 
		if(!Character.isDigit(stringToParse.charAt(index)) || index == 0) {
			return -1;
		}
		
		if(!Character.isWhitespace(stringToParse.charAt(index - 1)) && stringToParse.charAt(index - 1) != '-') {
			return -1;
		}
		
		if(index == (stringToParse.length() - 1)) {
			return index;
		}
		
		while(index < stringToParse.length() - 1) {
			index++;
			if(Character.isDigit(stringToParse.charAt(index))){
				continue;
			}
			else if(Character.isWhitespace(stringToParse.charAt(index))){
				return index - 1;
			}
			else {
				return - 1;
			}
		}
		return index;
	}
	
	/**
	 * Just splits rest of args into String[] 
	 */
	private void parseOtherTokens(){
		String[] array = stringToParse.split("\\s"); // \s - any whitespace characters
		ArrayList<String> result = new ArrayList<>();
		
		// if args are divided by multi whitespace characters, then array may have empty strings
		for(String s:array) {
			if(!s.isBlank()) {
				result.add(s);
			}
		}
		
		args = result.toArray(args);
	}
	
	/**
	 * Check whether the phrase consists of a single word.
	 * 
	 * @return <code>true</code> if the phrase consists of a single word, otherwise <code>false</code>.
	 */
	public boolean isPhraseOfSingleWord() {
		if(phrase.isBlank()) {
			return false;
		}
		
		String[] array = phrase.split("\\s"); // \s - any whitespace characters
		ArrayList<String> result = new ArrayList<>();
		
		// if words are divided by multi whitespace characters, then array may have empty strings
		for(String s:array) {
			if(!s.isBlank()) {
				result.add(s);
			}
		}
		
		return result.size() == 1;
	}
	
	/**
	 * Returns values of the Parser inner fields.
	 * Used for debug purposes only. 
	 */
	public String toString() {
		StringBuilder sb  = new StringBuilder();
		sb.append("commandName = " + commandName + "\n");
		sb.append("notParsedArgs = " + notParsedArgs + "\n");
		sb.append("phrase = " + phrase + "\n");
		sb.append("from = " + from + "\n");
		sb.append("to = " + to + "\n");
		sb.append("args = " + Arrays.toString(args) + "\n");
		
		return sb.toString();
	}
	
	/**
	 * Tests behavior of the Parser with the given command
	 * @param stringToParse - command to test.
	 */
	private static void test(String stringToParse) {
		System.out.println("==================================================");
		System.out.println(stringToParse);
		System.out.println("==================================================");
		System.out.println(new Parser(stringToParse));
	}
	
	public static void main(String[] args) {
		test(" ");
		test("unknown with unknown arguments");
		test("create with unknown arguments");
		test("create 	with     unknown 	 	arguments");
		test("help 	10  -");
		test("help 	10  -m");
		test("help 	10  -5");
		test("help 	10  -579");
		test("help 	10  -  57 ar");
		test("help 	10  -  57ar");
		test("help 	1  -  57 ar");
		test("help 	123  -  57 ar");
		test("help 	123-  57 ar");
		test("help 	123	-  57 ar");
		test("help 	123	  57 ar");
		test("help 	123--57 ar");
		test("help 	123- -57 ar");
		test("help 	arg0 136 - 8963 arg1 arg2");
		test("help 	arg0 136 - 8963 phrase arg1 arg2");
		test("help 	phrase arg1 arg2 arg0 136 - 8963");
		test("help 0-3");
		test("help");
		test("search phrase string");
	}
}
