package tea.commands;

import java.io.IOException;
import java.nio.file.Files;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>create</code> command.
 */
class CommandCreate extends AbstractCommandWorkingWithPaths {
	
	CommandCreate(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments: <br>
	 * <code>Filename</code> - string with a name of a non-existent file.<br>
	 * <b>?</b>        
	 */
	@Override
	protected boolean uniqInitialization() {			
		if(Files.exists(path)) {
			setErrorMessage("File: " + path.normalize() + " already exists.");
			return parametersSetCorrectly = false;
		}
		
		return parametersSetCorrectly = true;
	}

	/**
	 * Reads content of the file and saves it to the Storage.
	 */
	@Override
	protected void performUniqWork() {
		try {
			Files.createFile(path);
		} catch (IOException e) {
			printStream.println("Cannot create file: " + path.normalize());
			return;
		}
		
		editor.setFile(path);
		// file is empty but we should read it to initialize Storage
		readFile(false);
		editor.setMode(EMode.UPDATE);
	}

	@Override
	public String getHelpMessage() {
		return "create <filename>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Creates new file for editing and switches to the update mode.\n";
	}
}
