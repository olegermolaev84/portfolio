package tea.commands;

import tea.core.EMode;
import tea.core.Editor;
import tea.tools.Console;

/**
 * Implements <code>exit</code> command.
 */
class CommandExit extends AbstractCommand {

	CommandExit(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Exits the program.
	 */
	@Override
	protected void performUniqWork() {
		saveChanges();
		editor.setExit();
	}
	
	/** If the file is changed, then tries to save changes. */
	protected void saveChanges() {
		if(editor.isFileChanged()) {
			printStream.println("File is updated. Whould you like to save changes? (Y/N)");
			
			boolean correct_answer = false;
			while(!correct_answer) {
				String answer = Console.readLine("enter answer> ").strip().toUpperCase();
				
				if(answer.equals("YES") || answer.equals("Y")) {
					var save = ICommand.create(ESupportedCommands.SAVE.toString(), editor);
					save.initialize();
					save.perform();
					if(!save.getErrorMessage().isBlank()) {
						printStream.println("Whould you like to try save changes again?");
						continue;
					}
					correct_answer = true;
				}
				else if(answer.equals("NO") || answer.equals("N")) {
					correct_answer = true;
				}
				else {
					printStream.println("Cannot recognize your answer. Please enter one of YES/NO/Y/N");
				}
			}
		}
	}

	@Override
	public String getHelpMessage() {
		return "exit\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Exits the programm.\n";
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return true;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
