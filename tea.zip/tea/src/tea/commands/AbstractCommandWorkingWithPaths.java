package tea.commands;

import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements common functionality for commands: <br><code>read, update, create, cp.</code>
 *
 */
abstract class AbstractCommandWorkingWithPaths extends AbstractCommand {

	protected Path path;
	
	AbstractCommandWorkingWithPaths(Editor editor, Parser parser) {
		super(editor, parser);
	}
	
	/**
	 * Performs common initialization for all commands working with Path.
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		String path_name = parser.getNotParsedArgs().strip();
		if(path_name.isEmpty()) {
			setErrorMessage("Path is not provided.");
			return parametersSetCorrectly = false;		
		}
		
		try {
			path = Paths.get(path_name); 
		}
		catch (InvalidPathException e) {
			setErrorMessage("Given path name: \"" + path_name + "\" has unsupported characters.");
			return parametersSetCorrectly = false;
		}
		
		path = editor.getDirecory().resolve(path);
		
		return uniqInitialization();
	}
	
	/**
	 * Performs unique initialization of sub commands.
	 * @return <code>true</code> if arguments are applicable, otherwise <code>false</code>.
	 */
	protected abstract boolean uniqInitialization();
	
	/**
	 * Reads file content and saves it to Storage. This method a wrapper for Storage.readFile() method
	 * with handling of IOException.
	 * @param forReadOnly - indicates whether changing of the file allowed or not.
	 */
	protected void readFile(boolean forReadOnly) {
		try {
			editor.getStorage().readFile(path, forReadOnly);
		} catch (IOException e) {
			printStream.println("Error occured while file reading ...");
			editor.setExit(); 
			return;
		}
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return true;
		case READ: 	return false;
		case UPDATE:return false;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
