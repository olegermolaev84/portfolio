package tea.commands;

import java.util.TreeMap;

import tea.core.EMode;
import tea.core.Editor;
import tea.core.Storage;
import tea.tools.Console;

/**
 * Implements <code>replace</code> command.
 *
 */
class CommandReplace extends CommandSearch{

	/** Currently supported variations of the command. */
	private enum ActionToPerform{
		REPLACE, REPLACE_FROM_BUFFER, SEARCH_AND_REPLACE;
	}
	
	private ActionToPerform actionToPerform; 
	private TreeMap<Integer, String> replacedLines = new TreeMap<>();
	private TreeMap<Integer, String> newLines      = new TreeMap<>();
	
	CommandReplace(Editor editor, Parser parser) {
		super(editor, parser);
	}
	
	/**
	 * Applicable arguments:<br>
	 * <code>phrase</code> "phrase"<br>
	 * <code>ci phrase</code> "phrase" <br>
	 * <code>whole phrase </code> "phrase" <br>
	 * <code>ci whole phrase </code> "phrase"<br>
	 * Above variations with range of numbers in format "from"-"to"<br>
	 * No arguments<br>
	 * <code>buffer</code> <br>
	 * <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		// without arguments
		if(parser.isNoSpecialArgs()
				&& parser.getArgs().length == 0) 
		{
			actionToPerform = ActionToPerform.REPLACE;
			return parametersSetCorrectly = true;
		}
		
		// buffer
		else if(parser.isNoSpecialArgs()
				&& parser.getArgs().length == 1
				&& parser.getArgs()[0].equalsIgnoreCase("buffer")) 
		{
			actionToPerform = ActionToPerform.REPLACE_FROM_BUFFER;
			return parametersSetCorrectly = true;
		}
		
		// any variations with phrase
		else if(!parser.getPhrase().isBlank()) {
			if(parser.getFrom() >=0 && parser.getFrom() > parser.getTo()) {
				setErrorMessage("Range of lines is set incorrectly");
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.SEARCH_AND_REPLACE;
			return initializeSearchMode();
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}	
	}
	
	/**
	 * Depending on mode: <br>
	 * 1. replaces the current line either from buffer or by requiring new line from the customer. <br>
	 * 2. replaces some phrase in all text or in the range of lines. <br>
	 */
	@Override
	protected void performUniqWork() {
		
		if(editor.getStorage().getNumberOfLines() == 0) {
			printStream.println("File is emprty. No lines to be replaced");
			return;
		}
		
		Storage.CurrentLine line = editor.getStorage().getCurrentLine();
		
		switch(actionToPerform) {
		case REPLACE:{
			replacedLines.put(line.pos(), line.line());
			String replacementString = Console.readLine("type new content> ");
			newLines.put(line.pos(), replacementString);
			break;
		}
		case REPLACE_FROM_BUFFER:{
			replacedLines.put(line.pos(), line.line());
			newLines.put(line.pos(), editor.getBuffer());
			break;
		}
		case SEARCH_AND_REPLACE:
			searchAndReplce();
			break;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + actionToPerform);
		}
		
		editor.getStorage().replaceLines(newLines);
	}
	
	/**
	 * Replaces phrase in all text or in the range of lines.
	 */
	private void searchAndReplce() {
		String replacementPhrase = Console.readLine("enter replacement phrase> ");
		
		// save cursor position in order to reestablish it later.
		int cursorPosition = editor.getStorage().getCurrentLine().pos();

		editor.getStorage().setCursor(parser.getFrom() == -1?0:parser.getFrom());

		do {
			if(!currentLineHasSearchPhrase()) {
				continue;
			}
			var line = editor.getStorage().getCurrentLine();
			replacedLines.put(line.pos(), line.line());
			
			String replacementString = getReplacementString(line.line(), replacementPhrase);
			newLines.put(line.pos(), replacementString);	
		}while(editor.getStorage().next() && (parser.getTo() < 0?true:editor.getStorage().getCurrentLine().pos() <= parser.getTo()));

		editor.getStorage().setCursor(cursorPosition == -1 ? 0 : cursorPosition);	
	}
	
	/**
	 * Performs replacement for the given line and returns result string.
	 * 
	 * @param origLine - string in which phrase is to be replaced.
	 * @param replacementPhrase - new phrase to be placed instead of the searched phrase.
	 * @return - string with replaced phrase.
	 */
	private String getReplacementString(String origLine, String replacementPhrase) {
		if(!search_ci && !search_whole) {
			return origLine.replace(parser.getPhrase(), replacementPhrase);
		}
		else {
			String phraseToSearch;
			String lineToProcess;
			
			if(search_ci) {
				phraseToSearch = parser.getPhrase().toUpperCase();
				lineToProcess = origLine.toUpperCase();
			}
			else {
				phraseToSearch = parser.getPhrase();
				lineToProcess = origLine;
			}
			
			StringBuilder sb = new StringBuilder();
			
			int fromIndex = 0;
			int indexOfPhrase = 0;
			while((indexOfPhrase = lineToProcess.indexOf(phraseToSearch, fromIndex)) != - 1){
				if(search_whole) {
					if( (indexOfPhrase > 0 && !Character.isWhitespace(origLine.codePointAt(indexOfPhrase - 1)))
							||( (indexOfPhrase + phraseToSearch.length()) < (origLine.length() - 1)
									&& !Character.isWhitespace(origLine.codePointAt(indexOfPhrase + phraseToSearch.length())) ) )
					{
						sb.append(origLine.substring(fromIndex, indexOfPhrase + phraseToSearch.length()));
						fromIndex = indexOfPhrase + phraseToSearch.length();
						continue;
					}
				}
				sb.append(origLine.substring(fromIndex, indexOfPhrase) + replacementPhrase);
				fromIndex = indexOfPhrase + phraseToSearch.length();
			}
			sb.append(origLine.substring(fromIndex));
			return sb.toString();
		}
	}
	
	@Override
	public boolean contentChanged() {
		return newLines.size() > 0;
	}
	
	@Override
	public void undo() {
		editor.getStorage().replaceLines(replacedLines);
	}
	
	@Override 
	public void redo() {
		editor.getStorage().replaceLines(newLines);
	}

	@Override
	public String getHelpMessage() {
		return "replace [buffer]\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Clears the current line and offers to type new content. \n" 
	            + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "If the <buffer> key word is specified, then the line from the buffer is inserted.\n" 
		      + "replace [ci] [whole] [<from>-<to>] phrase <phrase>\n"
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Replaces all occurs of <phrase> with new phrase. \n" 
	            + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "If <whole> key word specified, then searches only lines which contain exact the same word as in <phrase>.\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "<whole> option is applicable for single word phrase only.\n" 
	            + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "<ci> option allows to find lines case-insensitively.\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "If <from>-<to> option specified, then replaces the phrase only in the specified range.\n";
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
