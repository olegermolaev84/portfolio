package tea.commands;

import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>ls</code> command.
 */
class CommandLs extends AbstractCommand {

	CommandLs(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Prints the absolute path of the current directory and files and directories in it.
	 */
	@Override
	protected void performUniqWork() {
		try {
			printStream.println(editor.getDirecory());
			Files.list(editor.getDirecory()).forEach(path->{
				printStream.print("    |---  ");
				printStream.print(Files.isDirectory(path)?"DIR:  ":"FILE: ");
				printStream.print(Files.isReadable(path)?"R":"-");
				printStream.print(Files.isWritable(path)?"W":"-");
				printStream.print(Files.isExecutable(path)?"E":"-");
				try {
					LocalDate date = LocalDate.ofInstant(Files.getLastModifiedTime(path).toInstant(), ZoneId.systemDefault());
					LocalTime time = LocalTime.ofInstant(Files.getLastModifiedTime(path).toInstant(), ZoneId.systemDefault());
					printStream.printf(" %td-%tm-%tY %tT", date, date, date, time);
				} catch (IOException e) {}
				printStream.println("   " + path.getFileName());
			});
		} catch (IOException e) {
			printStream.println("Cannot access directory: " + editor.getDirecory());
			return;
		}
	}

	@Override
	public String getHelpMessage() {
		return "ls\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Prints the absolute path of the current directory and list of files and directories in it.\n";
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return true;
		case READ: 	return false;
		case UPDATE:return false;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
