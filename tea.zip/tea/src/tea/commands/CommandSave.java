package tea.commands;

import java.io.IOException;
import java.nio.file.Files;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>save</code> command.
 */
class CommandSave extends AbstractCommand {

	CommandSave(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Saves changes to the file.
	 */
	@Override
	protected void performUniqWork() {
		
		try {
			Files.write(editor.getFile(), editor.getStorage().getLines());
		} catch (IOException e) {
			// before printing the error message, save it. It necessary to check saving results when
			// command called from the exit command.
			setErrorMessage("Cannot save the file: " + editor.getFile().normalize());
			printStream.println(getErrorMessage());
		}
		
		editor.getRedoQueue().clear();
		editor.getUndoQueue().clear();
	}

	@Override
	public String getHelpMessage() {
		return "save\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Save changes to the file.\n" 
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Note: after this step changes cannot be undone by <undo> command.\n";
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
