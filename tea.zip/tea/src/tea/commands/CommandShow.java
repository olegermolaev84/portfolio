package tea.commands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import tea.core.EMode;
import tea.core.Editor;
import tea.tools.Console;

/**
 * Implements <code>show</code> command.
 */
class CommandShow extends AbstractCommand {

	/** list of supported command variations. */
	private enum ActionToPerform {
		CURRENT, NEXT, PREV, DENOTED_LINE, ALL, FROM_TO, SORTED_LINES, UNIQ_WORDS, UNIQ_WORDS_WITH_NUM, BUFFER;
	}

	private ActionToPerform actionToPerform;

	CommandShow(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments:<br>
	 * No arguments<br>
	 * <code>next</code><br>
	 * <code>prev</code><br>
	 * Single number<br>
	 * <code>all</code><br>
	 * Range of numbers in format from-to<br>
	 * <code>sorted alpha</code><br>
	 * <code>sorted length</code><br>
	 * <code>uniq words</code><br>
	 * <code>uniq words number</code><br>
	 * <code>buffer</code><br>
	 * <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		String[] args = parser.getArgs();
		
		// show
		if(parser.getNotParsedArgs().isBlank()) {
			actionToPerform = ActionToPerform.CURRENT;
			return parametersSetCorrectly = true;
		}
		
		// show next
		else if(args.length == 1 
				&& args[0].equalsIgnoreCase("next") 
				&& parser.isNoSpecialArgs()) 
		{
			actionToPerform = ActionToPerform.NEXT;
			return parametersSetCorrectly = true;
		}
		
		// show prev
		else if(args.length == 1 
				&& args[0].equalsIgnoreCase("prev") 
				&& parser.isNoSpecialArgs()) 
		{
			actionToPerform = ActionToPerform.PREV;
			return parametersSetCorrectly = true;
		}
		
		// show <num>
		else if(args.length == 1 
				&& Parser.isInteger(args[0]) 
				&& parser.isNoSpecialArgs()) 
		{
			if(!checkIndex(parser.getArgs()[0])) {
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.DENOTED_LINE;
			return parametersSetCorrectly = true;
		}
		
		// show all
		else if(args.length == 1 
				&& args[0].equalsIgnoreCase("all") 
				&& parser.isNoSpecialArgs()) 
		{
			actionToPerform = ActionToPerform.ALL;
			return parametersSetCorrectly = true;
		}
		
		// show <from>-<to>
		else if(args.length == 0 
				&& parser.getTo() > -1 
				&& parser.getFrom() > -1) 
		{
			if(!checkFromToRange()) {
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.FROM_TO;
			return parametersSetCorrectly = true;
		}
		
		// show sorted
		else if(args.length == 2 
				&& args[0].equalsIgnoreCase("sorted") 
				&& (args[1].equalsIgnoreCase("alpha") || args[1].equalsIgnoreCase("length")) 
				&& parser.isNoSpecialArgs()) 
		{
			actionToPerform = ActionToPerform.SORTED_LINES;
			return parametersSetCorrectly = true;
		}
		
		// show uniq words
		else if(args.length == 2
				&& args[0].equalsIgnoreCase("uniq") 
				&& args[1].equalsIgnoreCase("words") 
				&& parser.isNoSpecialArgs())
		{
			actionToPerform = ActionToPerform.UNIQ_WORDS;
			return parametersSetCorrectly = true;
		}
		
		// show uniq words number
		else if(args.length == 3
				&& args[0].equalsIgnoreCase("uniq") 
				&& args[1].equalsIgnoreCase("words") 
				&& args[2].equalsIgnoreCase("number")
				&& parser.isNoSpecialArgs()) 
		{
			actionToPerform = ActionToPerform.UNIQ_WORDS_WITH_NUM;
			return parametersSetCorrectly = true;
		}
		
		// show buffer
		else if(args.length == 1
				&& args[0].equalsIgnoreCase("buffer")
				&& parser.isNoSpecialArgs())
		{
			actionToPerform = ActionToPerform.BUFFER;
			return parametersSetCorrectly = true;
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
	}

	/**
	 * Shows lines from the file.
	 * Behavior of the command depends on the denoted arguments.
	 */
	@Override
	protected void performUniqWork() {
		switch(actionToPerform) {
		case ALL: 
		case FROM_TO:
		case SORTED_LINES: showSeveralLines(); break;
		case DENOTED_LINE: showDenotedLine(); break;
		case CURRENT: showCurrentLine(); break;
		case NEXT: showNext();break;
		case PREV: showPrev(); break;
		case UNIQ_WORDS:
		case UNIQ_WORDS_WITH_NUM:showUniqWords(); break;
		case BUFFER: printStream.println(editor.getBuffer()); break;
		default:
			assert false: "Unhandled constant of enum ActionToPerform: " + actionToPerform;
		}
	}
	
	/**
	 * Prints lines from the file for modes: ALL, FROM_TO, SORTED_LINES.
	 */
	private void showSeveralLines() {	
		List<String> lines = editor.getStorage().getLines();
		
		if(actionToPerform == ActionToPerform.SORTED_LINES) {
			lines = new ArrayList<String>(lines); 
			
			if(parser.getArgs()[1].equalsIgnoreCase("alpha")) {
				Collections.sort(lines); // lexicographically
			}
			else {
				Collections.sort(lines, (s1, s2)->s1.length() - s2.length()); // by length
			}
		}
		
		int startIndex = 0; // for ALL and SORTED_LINES modes
		if(actionToPerform == ActionToPerform.FROM_TO) {
			startIndex = Integer.valueOf(parser.getFrom());
		}
			
		int endIndex = lines.size() - 1; // for ALL and SORTED_LINES modes
		if(actionToPerform == ActionToPerform.FROM_TO) {
			endIndex = Integer.valueOf(parser.getTo());
		}
		
		
		var iter = lines.listIterator(startIndex);
		int index = startIndex;
		
		int numberOfLinesPrinted = 0;
		while(index <= endIndex && iter.hasNext()) {
			if (numberOfLinesPrinted == NUM_LINES_TO_BE_PRINTED_AT_ONCE) {
				// user should press Enter to show another portion of lines
				// or STOP and press Enter to stop showing
				if(Console.readLine(". . . . . >").strip().equalsIgnoreCase("stop")) {
					break;
				}
				else {
					numberOfLinesPrinted = 0;
				}
			}
		
			printStream.println("<" + index + "> " + iter.next());
			numberOfLinesPrinted++;
			index++;
		}
	}
	
	/**
	 * Displays the denoted line and its number.
	 */
	private void showDenotedLine() {	
		editor.getStorage().setCursor(Integer.valueOf(parser.getArgs()[0]));
		showCurrentLine();
	}
	
	/**
	 * Displays the current line and its number.
	 */
	private void showCurrentLine() {	
		var currLine = editor.getStorage().getCurrentLine();
		
		if (currLine.pos() == -1) {
			printStream.println("file is empty");
		}
		else {
			printStream.println("<" + currLine.pos() + "> " + currLine.line());
		}
	}
	
	/**
	 * Displays the next line from the file and moves cursor to it.
	 */
	private void showNext() {
		if(editor.getStorage().next()) {
			showCurrentLine();
		}
		else {
			printStream.println("EOF is reached");
		}
	}
	
	/**
	 * Displays the previous line from the file and moves cursor to it.
	 */
	private void showPrev() {
	
		if(editor.getStorage().previous()) {
			showCurrentLine();
		}
		else {
			printStream.println("BOF is reached");
		}
	}
	
	/**
	 * Displays unique words in sorted order.
	 */
	private void showUniqWords() {	
		editor.getStorage().getMapOfWords().forEach((key, value)->{
			printStream.println(key + (actionToPerform == ActionToPerform.UNIQ_WORDS_WITH_NUM ? " = " + value:""));
		});
			
	}

	@Override
	public String getHelpMessage() {
		return "show\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Shows the current line and its number. \n" 
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "If the file just opened and not empty shows the first line from the file. \n" 
		   + "show next\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows the next line and its number and moves cursor to it.\n" 
		   + "show prev\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows the previous line and its number and moves cursor to it.\n" 
		   + "show <num>\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows the line number <num> and moves cursor to it.\n" 
		   + "show all\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows all lines from the file with their numbers. " 
			    + "Lines are shown in portions of " + AbstractCommand.NUM_LINES_TO_BE_PRINTED_AT_ONCE +  " lines.\n"
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "To print the next portion press the Enter button. To stop printing type STOP and press Enter.\n"
		   + "show <from>-<to>\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows lines from the denoted range with numbers.\n"
		   + "show sorted <alpha|length>\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows all lines with numbers from the file in the sorted order.\n"
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "alpha - sorts lexographically.\n" 
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "length - sorts according to the length of each line.\n"
		   + "show uniq words [number]\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows uniq words in the text in sorted order.\n" 
			    + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "If <number> key word specified, then also shows number of occurrences.\n"
		   + "show buffer\n" 
		        + " ".repeat(OFFSET_IN_HELP_MESSAGE) 
			    + "Shows content of the buffer. \n" ;
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
