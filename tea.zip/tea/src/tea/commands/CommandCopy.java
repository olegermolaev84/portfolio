package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>copy</code> command.
 */
class CommandCopy extends AbstractCommand {

	/** index of line to copy */
	private int num = -1;
	
	CommandCopy(Editor editor, Parser parser) {
		super(editor, parser);
	}
	
	/**
	 * Applicable arguments: <br>
	 * No arguments<br>
	 * Number of the line to copy<br>
	 * <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.isNoSpecialArgs()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		// no arguments
		if(parser.getArgs().length == 0) {
			num = editor.getStorage().getCurrentLine().pos();
		}
		
		// <num>
		else if(parser.getArgs().length == 1
				&& Parser.isInteger(parser.getArgs()[0])) {
			
			num = Integer.valueOf(parser.getArgs()[0]);
			if(num < 0 || num >= editor.getStorage().getNumberOfLines()) {
				setErrorMessage("Specified number is out of range. Enter number from  0 to " + (editor.getStorage().getNumberOfLines() -1));
				return parametersSetCorrectly = false;
			}
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		return parametersSetCorrectly = true;
	}

	/** Copies specified line to buffer. */
	@Override
	protected void performUniqWork() {
		if(num == editor.getStorage().getCurrentLine().pos()) {
			editor.setBuffer(editor.getStorage().getCurrentLine().line());
		}
		else {
			editor.setBuffer(editor.getStorage().getLines().get(num));
		}
	}
	
	@Override
	public String getHelpMessage() {
		return "copy [num]\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Copies current line or line of number <num> to buffer.\n";
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
