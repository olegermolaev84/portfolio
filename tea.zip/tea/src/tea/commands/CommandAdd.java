package tea.commands;

import tea.core.EMode;
import tea.core.Editor;
import tea.tools.Console;

/**
 * Implements <code>add</code> command.
 */
class CommandAdd extends AbstractCommand {

	/**
	 * Currently supported variations of the command.
	 */
	private enum ActionToPerform{
		ADD_BEFORE, ADD_AFTER;
	}
	
	/** Indicates with which arguments the command is started with. */
	private ActionToPerform actionToPerform;
	
	/** String from buffer. Also it stores added line for <code>redo</code> command. */
	private String bufferedLine;
	
	/** Stores the line's index which should be removed in case of <code>undo</code> command. */
	private int indexToRemove = -1;
	
	CommandAdd(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments: <br>
	 * <code>before "index" </code><br>
	 * <code>before "index" buffer</code><br>
	 * <code>after "index" </code><br>
	 * <code>after "index" buffer</code><br>
	 * <b>?</b>  
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.isNoSpecialArgs()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		// before
		if(parser.getArgs().length ==  2
				&& parser.getArgs()[0].equalsIgnoreCase("before"))
		{
			if(!checkIndex(parser.getArgs()[1])) {
				return parametersSetCorrectly = false;
			}
			
			actionToPerform = ActionToPerform.ADD_BEFORE;
			return parametersSetCorrectly = true;
		}
		
		// before buffer
		else if(parser.getArgs().length == 3 
				&& parser.getArgs()[0].equalsIgnoreCase("before")
				&& parser.getArgs()[2].equalsIgnoreCase("buffer"))
		{
			if(!checkIndex(parser.getArgs()[1])) {
				return parametersSetCorrectly = false;
			}
			
			actionToPerform = ActionToPerform.ADD_BEFORE;
			return parametersSetCorrectly = true;
		}
		
		// after
		else if(parser.getArgs().length == 2 
				&& parser.getArgs()[0].equalsIgnoreCase("after"))
		{
			if(!checkIndex(parser.getArgs()[1])) {
				return parametersSetCorrectly = false;
			}
			
			actionToPerform = ActionToPerform.ADD_AFTER;
			return parametersSetCorrectly = true;
		}
		
		// after buffer
		else if(parser.getArgs().length == 3 
				&& parser.getArgs()[0].equalsIgnoreCase("after")
				&& parser.getArgs()[2].equalsIgnoreCase("buffer"))
		{
			if(!checkIndex(parser.getArgs()[1])) {
				return parametersSetCorrectly = false;
			}
			
			actionToPerform = ActionToPerform.ADD_AFTER;
			return parametersSetCorrectly = true;
		}
		
		else {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;			
		}
	}

	/**
	 * Adds new line to the text file and sets cursor to it.
	 */
	@Override
	protected void performUniqWork() {
		
		if(parser.getArgs().length == 3 
				&& parser.getArgs()[2].equalsIgnoreCase("buffer")) {
			bufferedLine = editor.getBuffer(); 
		}
		else {
			bufferedLine = Console.readLine("enter text> ");
		}
		
		indexToRemove = Integer.valueOf(parser.getArgs()[1]);
				
		if(actionToPerform == ActionToPerform.ADD_AFTER
				&& indexToRemove < editor.getStorage().getNumberOfLines()) {
			indexToRemove++;	
		}
		
		editor.getStorage().addLine(bufferedLine, indexToRemove);
	}

	@Override
	public String getHelpMessage() {
		return "add <before|after> <num> [buffer]\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Adds new line before or after the line with index <num> and offers to type it. " 
				+ "Sets cursor to the new line.\n" 
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "If the <buffer> key word is specified, then the line from the buffer is inserted.\n";
	}

	@Override
	public boolean contentChanged() {
		return indexToRemove >= 0;
	}

	@Override
	public void undo() {
		editor.getStorage().removeLine(indexToRemove);
	}
	
	@Override
	public void redo() {
		editor.getStorage().addLine(bufferedLine, indexToRemove);
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
