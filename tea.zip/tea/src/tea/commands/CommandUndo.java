package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>undo</code> command.
 *
 */
class CommandUndo extends AbstractCommand {

	CommandUndo(Editor editor, Parser parser) {
		super(editor, parser);
	}

	@Override
	public String getHelpMessage() {
		return "undo\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Undoes previous command.\n";
	}

	/**
	 * Undoes the previous modifying command.
	 */
	@Override
	protected void performUniqWork() {
		var undoQueue = editor.getUndoQueue();
		var redoQueue = editor.getRedoQueue();
		
		ICommand command;
		if((command = undoQueue.pollLast()) != null) {
			command.undo();
			redoQueue.addLast(command);
		}
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
