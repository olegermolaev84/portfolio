package tea.commands;

import java.io.IOException;
import java.nio.file.Files;

import tea.core.Editor;

/**
 * Implements <code>cp</code> command.
 *
 */
class CommandCp extends AbstractCommandWorkingWithPaths {
	
	CommandCp(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments: <br>
	 * <code>pathname</code> - string with a name of an existent path in the current directory.<br>
	 * <b>?</b> 
	 */
	@Override
	protected boolean uniqInitialization() {		
		if(!Files.exists(path)) {
			setErrorMessage("Direcory: " + path.normalize() + " does not exist.");
			return parametersSetCorrectly = false;
		}
		
		else if(!Files.isDirectory(path)) {
			setErrorMessage(path.normalize() + " is not directory.");
			return parametersSetCorrectly = false;
		}
		
		return parametersSetCorrectly = true;
	}

	/**
	 * Changes the directory.
	 */
	@Override
	protected void performUniqWork() {
		try {
			editor.setDirectory(path.toRealPath());
		} catch (IOException e) {
			printStream.println("Cannot access directory: " + path.normalize().toAbsolutePath());
			editor.setExit();
		}
	}

	@Override
	public String getHelpMessage() {
		return "cp <path>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Goes to the denoted directory.\n";
	}
}
