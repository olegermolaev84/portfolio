package tea.commands;

import java.util.EnumSet;

import tea.core.EMode;
import tea.core.Editor;

/**
 * A Class which implements this interface represents one command. 
 */
public interface ICommand {
	
	/**
	 * Checks the given arguments. If they are wrong returns <code>false</code>.
	 *
	 * @return <code>true</code> if arguments are applicable, otherwise <code>false</code>.
	 */
	boolean initialize();
	
	/**
	 * Executes the command. Throws an exception if the command not initialized
	 * (<code>Initialize</code> not called or called with invalid parameters).
	 * 
	 * @throws UnsupportedOperationException if the command not initialized.
	 */
	void perform() throws UnsupportedOperationException;
	
	/**
	 * Returns string with error description which can occur while command initializing.
	 * 
	 * @return string with error description.
	 */
	String getErrorMessage();
	
	/**
	 * Cancels the command.
	 * 
	 * @throws UnsupportedOperationException if the command has not changed the text file.
	 */
	default void undo() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Performs the command after it has been undone.
	 * 
	 * @throws UnsupportedOperationException if the command has not changed the text file.
	 */
	default void redo() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Returns string with verbose information how the command can be used.
	 * 
	 * @return string with verbose information how the command can be used.
	 */
	String getHelpMessage();
	
	/** 
	 * Returns whether the command supported in the given mode. 
	 * @param mode - mode to test.
	 * @return <code>true</code> if supported, otherwise <code>false</code>.
	 */
	boolean supportedInMode(EMode mode);
	
	/**
	 * Parsers the given string which should store command name and its arguments and creates corresponding command.
	 * 
	 * @param stringWithCommand - string with command name and its arguments.
	 * @param editor - not null Editor class object.
	 * @return created command or <code>null</code> if the given string has incorrect command name.
	 */
	public static ICommand create(String stringWithCommand, Editor editor) {
		Parser parser = new Parser(stringWithCommand);
		
		try {
			return create(Enum.valueOf(ESupportedCommands.class, parser.getCommandName().toUpperCase()), 
					editor,
					parser);
		}
		catch (IllegalArgumentException e) {
			return null;
		}
	}
	
	/**
	 * Creates new command of the denoted type.
	 * 
	 * @param e_command - ESupportedCommands enum constant. Defines type of the command to be created.
	 * @param editor - Editor class object
	 * @param parser - Parser class object
	 * @return created corresponding ICommand class object
	 */
	private static ICommand create(ESupportedCommands e_command, Editor editor, Parser parser) {

		switch (e_command) {
		case CREATE:	return new CommandCreate(editor, parser);
		case ADD:		return new CommandAdd(editor, parser);
		case COPY:		return new CommandCopy(editor, parser);
		case CP:		return new CommandCp(editor, parser);
		case EXIT:		return new CommandExit(editor, parser);
		case HELP:		return new CommandHelp(editor, parser);
		case LS:		return new CommandLs(editor, parser);
		case MENU:		return new CommandMenu(editor, parser);
		case READ:		return new CommandRead(editor, parser);
		case REDO:		return new CommandRedo(editor, parser);
		case REMOVE:	return new CommandRemove(editor, parser);
		case REPLACE:	return new CommandReplace(editor, parser);
		case SAVE:		return new CommandSave(editor, parser);
		case SEARCH:	return new CommandSearch(editor, parser);
		case SHOW:		return new CommandShow(editor, parser);
		case STAT:		return new CommandStat(editor, parser);
		case UNDO:		return new CommandUndo(editor, parser);			
		case UPDATE:	return new CommandUpdate(editor, parser);
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + e_command);
		}
	}

	/**
	 * Returns set of supported for the denoted mode commands.
	 * @param mode - mode to test.
	 * @return set of supported for the denoted mode commands.
	 */
	static EnumSet<ESupportedCommands> getSupportedCommandsForMode(EMode mode) {
		var e_commands_set = EnumSet.noneOf(ESupportedCommands.class);

		for (ESupportedCommands e_command : ESupportedCommands.values()) {
			if (e_command.getModes().contains(mode)) {
				e_commands_set.add(e_command);
			}
		}

		return e_commands_set;
	}
}
