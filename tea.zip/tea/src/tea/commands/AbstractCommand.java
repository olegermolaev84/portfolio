package tea.commands;

import java.io.PrintStream;
import java.util.Objects;

import tea.core.Editor;

/**
 * Implements general functionality for all commands.
 *
 */
abstract class AbstractCommand implements ICommand {
	private boolean onPerformPrintHelp = false;
	
	/** Contains error description occurred while the command initializing. */
	private String  error = "";
	
	protected static final int OFFSET_IN_HELP_MESSAGE = 3;
	protected static final int NUM_LINES_TO_BE_PRINTED_AT_ONCE = 25;
	
	/** Should be set to <code> true</code> if the command initializing is successful. */
	protected boolean parametersSetCorrectly = false;
	
	protected final Parser      parser;
	protected final Editor      editor;
	protected final PrintStream printStream;
	
	protected AbstractCommand(Editor editor, Parser parser) {
		this.editor = Objects.requireNonNull(editor);
		this.parser = Objects.requireNonNull(parser);
		printStream = System.out;
	}
	 
	/**
	 * Default implementation for all commands without arguments. <br>
	 * Applicable arguments: <b>?</b>
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.getNotParsedArgs().isBlank()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
	
		return parametersSetCorrectly = true;
	}
	
	/**
	 * Executes common for all commands work and then unique work for certain command.
	 */
	@Override
	public final void perform() throws UnsupportedOperationException {
		if (!parametersSetCorrectly) {
			throw new UnsupportedOperationException(
					"Attempt to perform command without appropriate settings");
		}
		
		if(onPerformPrintHelp) {
			printStream.print(getHelpMessage());
			return;
		}
		
		performUniqWork();
		
		if(contentChanged()) {
			editor.getUndoQueue().addLast(this);
		}
	}
	
	/** 
	 * Checks whether the command called with <b>?</b> argument.
	 * @return <code>true</code> if the command called with <b>?</b> argument, otherwise <code>false</code>.
	 */
	protected final boolean isCommandCalledToPrintHelpAboutItself() {
		if(parser.getArgs().length == 1 
				&& parser.getArgs()[0].equals("?")
				&& parser.isNoSpecialArgs()) 
		{
			onPerformPrintHelp = true;
			return true;
		}
		return false;
	}
	

	@Override
	public final String getErrorMessage() {	return error;}
	protected final void setErrorMessage(String error) {this.error = error;}
	
	
	/**
	 * Check given index format for commands show "num", add after|before "num"
	 * @param index - string with index to check
	 * @return <code>true</code> if index has correct format, otherwise <code>false</code>.
	 */
	protected boolean checkIndex(String index) {
		if(editor.getStorage().getNumberOfLines() == 0) {
			if(!Parser.isInteger(index) || Integer.valueOf(index) != 0) {
				setErrorMessage("Expected correct index in bound from 0 to 0");
				return false;
			}
			else {
				return true;
			}
		}
		if(!Parser.isInteger(index)
				|| Integer.valueOf(index) < 0
				|| Integer.valueOf(index) >= editor.getStorage().getNumberOfLines()) {
			setErrorMessage("Expected correct index in bound from 0 to " + (editor.getStorage().getNumberOfLines() - 1));
			return false;	
		}
		return true;
	}
	
	/**
	 * Check given "from"-"to" range for commands like show "from"-"to", replace "from"-"to"
	 * @return <code>true</code> if range is correct, otherwise <code>false</code>.
	 */
	protected boolean checkFromToRange() {
		if(parser.getFrom() > parser.getTo()) {
			setErrorMessage("Range of lines is set incorrectly.");
			return false;
		}
		else if(editor.getStorage().getNumberOfLines() == 0) {
			setErrorMessage("file is empty");
			return false;
		}
		else if(parser.getFrom() >= editor.getStorage().getNumberOfLines() 
				|| parser.getTo() >= editor.getStorage().getNumberOfLines()) 
		{
			setErrorMessage("Range of lines is out of bounds. The range must be in (0-"
					+ (editor.getStorage().getNumberOfLines() - 1) + ").");
			return false;
		}
		
		return true;
	}
	
	/**
	 * Performs some unique work for certain command.
	 */
	protected abstract void performUniqWork();
	
	/**
	 * Shows whether the command has modified the text file or not.
	 * 
	 * @return <code>true</code> if the command can change the text file, otherwise
	 *         <code>false</code>
	 */
	protected boolean contentChanged() {
		return false;
	}
}
