package tea.commands;

import java.nio.file.Files;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>update</code> command.
 */
class CommandUpdate extends AbstractCommandWorkingWithPaths {
	
	CommandUpdate(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments: <br>
	 * <code>Filename</code> - string with a name of an existent file with enough
	 * permissions to update the file.<br>
	 * <b>?</b>
	 */
	@Override
	protected boolean uniqInitialization() {
		if(!Files.exists(path)) {
			setErrorMessage("File: " + path.normalize() + " not found");
			return parametersSetCorrectly = false;
		}
		else if(Files.isDirectory(path)){
			setErrorMessage("File: " + path.normalize() + " is directory");
			return parametersSetCorrectly = false;
		}
		else if(!Files.isWritable(path)) {
			setErrorMessage("Cannot open file: " + path.normalize() + " for updating");
			return parametersSetCorrectly = false;
		}
		
		return parametersSetCorrectly = true;
	}

	/**
	 * Reads content of the file and saves it to the Storage.
	 */
	@Override
	protected void performUniqWork() {
		editor.setFile(path);
		readFile(false);
		editor.setMode(EMode.UPDATE);
	}

	@Override
	public String getHelpMessage() {
		return "update <filename>\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Opens the file for updating and switches to the update mode.\n";
	}
}
