package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>redo</code> command.
 *
 */
class CommandRedo extends AbstractCommand {

	CommandRedo(Editor editor, Parser parser) {
		super(editor, parser);
	}

	@Override
	public String getHelpMessage() {
		return "redo\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Redoes previously undone command.\n";
	}

	/**
	 * Redoes previously undone command.
	 */
	@Override
	protected void performUniqWork() {
		var undoQueue = editor.getUndoQueue();
		var redoQueue = editor.getRedoQueue();
		
		ICommand command;
		if((command = redoQueue.pollLast()) != null) {
			command.redo();
			undoQueue.addLast(command);
		}
	}

	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return false;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
