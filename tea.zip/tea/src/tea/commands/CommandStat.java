package tea.commands;

import tea.core.EMode;
import tea.core.Editor;

/**
 * Implements <code>stat</code> command.
 */
class CommandStat extends AbstractCommand {

	/** list of supported command variations */
	private enum ActionToPerform{
		NUM_OF_SINGS, NUM_OF_WORDS, NUM_OF_UNIQ_WORDS, NUM_OF_LINES;
	}
	
	private ActionToPerform actionToPerform;
	
	CommandStat(Editor editor, Parser parser) {
		super(editor, parser);
	}

	/**
	 * Applicable arguments:<br>
	 * <code>num signs</code><br>
	 * <code>num words</code><br>
	 * <code>num uniq words</code><br>
	 * <code>num lines</code><br>
	 * <b>?</b> 
	 */
	@Override
	public boolean initialize() {
		if(isCommandCalledToPrintHelpAboutItself()) {
			return parametersSetCorrectly = true;
		}
		
		if(!parser.isNoSpecialArgs()) {
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		// first arg must be num
		if(parser.getArgs().length < 2 
				|| !parser.getArgs()[0].equalsIgnoreCase("num"))
		{
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		
		switch(parser.getArgs()[1].toLowerCase()) {
		case "sings":{
			if(parser.getArgs().length != 2) { 
				setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.NUM_OF_SINGS;
			break;
		}
		case "words":{
			if(parser.getArgs().length != 2) { 
				setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.NUM_OF_WORDS;
			break;
		}
		case "uniq":{
			if(parser.getArgs().length != 3 
					|| !parser.getArgs()[2].equalsIgnoreCase("words")) 
			{ 
				setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.NUM_OF_UNIQ_WORDS;
			break;
		}
		case "lines":{
			if(parser.getArgs().length != 2) { 
				setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
				return parametersSetCorrectly = false;
			}
			actionToPerform = ActionToPerform.NUM_OF_LINES;
			break;
		}
		default:{
			setErrorMessage("Unexpected arguments: " + parser.getNotParsedArgs());
			return parametersSetCorrectly = false;
		}
		}
		
		return parametersSetCorrectly = true;
	}

	/**
	 * Prints statistic information about the text file.
	 */
	@Override
	protected void performUniqWork() {	
		switch(actionToPerform) {
		case NUM_OF_SINGS:{
			printStream.println(editor.getStorage().getNumberOfSigns());
			break;
		}
		case NUM_OF_WORDS:{
			printStream.println(editor.getStorage().getNumberOfWords());
			break;
		}
		case NUM_OF_UNIQ_WORDS:{
			printStream.println(editor.getStorage().getNumberOfUniqWords());
			break;
		}
		case NUM_OF_LINES:{
			printStream.println(editor.getStorage().getNumberOfLines());
			break;
		}
		default:{
			assert false: "Unhandled constant of enum ActionToPerform: " + actionToPerform;
		}
		}
	}

	@Override
	public String getHelpMessage() {
		return 
			 "stat num signs\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Shows number of signs in the text.\n" 
		   + "stat num words\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Shows number of words in the text.\n" 
		   + "stat num uniq words\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Shows number of unique words in the text.\n" 
		   + "stat num lines\n"
				+ " ".repeat(OFFSET_IN_HELP_MESSAGE) 
				+ "Shows number of lines in the text.\n";
	}
	
	@Override
	public boolean supportedInMode(EMode mode) {
		switch(mode) {
		case MENU: 	return false;
		case READ: 	return true;
		case UPDATE:return true;
		default:
			throw new UnsupportedOperationException("not handled enum constant: " + mode);
		}
	}
}
