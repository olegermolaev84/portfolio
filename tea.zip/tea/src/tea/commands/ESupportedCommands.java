package tea.commands;

import java.util.Arrays;
import java.util.EnumSet;

import tea.core.EMode;

/**
 * Contains constants for each command. And information about in which mode each command is supported.
 */
enum ESupportedCommands {
	HELP   (EMode.MENU, EMode.READ, EMode.UPDATE),
	CP     (EMode.MENU),
	LS     (EMode.MENU),
	CREATE (EMode.MENU),
	UPDATE (EMode.MENU),
	READ   (EMode.MENU),
	EXIT   (EMode.MENU, EMode.READ, EMode.UPDATE),
	SHOW   (EMode.READ, EMode.UPDATE),
	SEARCH (EMode.READ, EMode.UPDATE),
	ADD    (EMode.UPDATE),
	REMOVE (EMode.UPDATE),
	REPLACE(EMode.UPDATE),
	COPY   (EMode.UPDATE),
	UNDO   (EMode.UPDATE),
	REDO   (EMode.UPDATE),
	SAVE   (EMode.UPDATE),
	MENU   (EMode.READ, EMode.UPDATE),
	STAT   (EMode.READ, EMode.UPDATE);
	
	/** Set of modes applicable for the command.*/
	private EnumSet<EMode> modes;
	
	private ESupportedCommands(EMode... modes) {
		this.modes = EnumSet.copyOf(Arrays.asList(modes));
	}
	
	/**
	 * Returns set of modes applicable for the command.
	 * @return set of modes applicable for the command.
	 */
	EnumSet<EMode> getModes(){return modes;}
}