package rbc.components;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Map;

import javax.swing.*;

import rbc.rbc;
import rbc.utils.GBC;

/**
 * Implements form for journal's records.
 *
 */
@SuppressWarnings("serial")
public class JournalDialog extends JDialog implements ICommonConstants{
	
	/**
	 * Constructor.
	 * @param owner the {@code Frame} from which the dialog is displayed
     * @param title  the {@code String} to display in the dialog's
     *     title bar
     * @param modal specifies whether dialog blocks user input to other top-level
     *     windows when shown. If {@code true}, the modality type property is set to
     *     {@code DEFAULT_MODALITY_TYPE} otherwise the dialog is modeless.
	 * @param journal map there the key is expression, the value is result.
	 */
	public JournalDialog(Frame owner, String title, boolean modal, Map<String, String> journal) {
		super(owner, title, modal);
		
		setBounds(owner.getX(), owner.getY(), owner.getWidth(), owner.getHeight());
		setResizable(false);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridBagLayout());
		
		
		int i = 0;
		var iter = journal.entrySet().iterator();
		while(iter.hasNext()) {
			var record = iter.next();
			
			var button = new RoundedButton((int)(getWidth()*0.9), 30, 5);
			button.setColors(GREY_COLOR, GREY_COLOR_PRESSED, GREY_COLOR_PRESSED);
			button.setText(record.getKey(), Color.BLACK, GENERAL_FONT);
			button.setWrapText(true);
			button.addActionListener((event)->{
				((rbc)owner).setExpression(record.getKey());
				dispose();
			});
			mainPanel.add(button, new GBC(0,i++));
			
			button = new RoundedButton((int)(getWidth()*0.9), 30, 5);
			button.setColors(GREEN_COLOR, GREEN_COLOR_PRESSED, GREEN_COLOR_PRESSED);
			button.setText("=" + record.getValue(), Color.WHITE, GENERAL_FONT);
			button.setWrapText(true);
			button.addActionListener((event)->{
				((rbc)owner).setExpression(record.getValue());
				dispose();
			});
			mainPanel.add(button, new GBC(0,i++).setInserts(0, 0, 5, 0));
		}
		
		JScrollPane scroll = new JScrollPane(mainPanel);
		add(scroll, BorderLayout.CENTER);
		
		var clearButton = new RoundedButton((int)(getWidth()*0.5), 30,5);
		clearButton.setColors(Color.BLACK, Color.BLACK, Color.BLACK);
		clearButton.setText("Clear", RED_COLOR, GENERAL_FONT);
		clearButton.addActionListener((event)->{
			((rbc)owner).clearJournal();
			dispose();
		});
		add(clearButton, BorderLayout.SOUTH);
		
		addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				// close the dialog on Enter and Esc
				if (e.getKeyChar() == KeyEvent.VK_ENTER || e.getKeyChar() == KeyEvent.VK_ESCAPE) {
					dispose();
				}
				else if(e.getKeyChar() == 'c' || e.getKeyChar() == 'C') {
					clearButton.pressAndRelease();
				}

			}});
	}
}
