package rbc.components;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.*;

/**
 * Implements button with rounded corners or round button.<br>
 * <b><u>Capability of this component:</u></b>
 * <ul> 
 * <li>Animation on pressing
 * <li>Multiline text
 * <li>Opportunity to draw some shapes on the button
 * </ul>
 *
 */
@SuppressWarnings("serial")
public class RoundedButton extends JComponent {
	private Color colorWhenReleased;
	private Color colorWhenPressed;
	private Color currentColor;
	private Color borderColor;
	private int   height;
	private int   initHeight;
	private int   width;
	private int   radius;
	private String text = "";
	private Color colorOfText;
	private Font fontOfText;
	private Font currentFont;
	private ArrayList<ActionListener> actionListeners = new ArrayList<>(1);
	private ArrayList<AdditionalShape> additionalShapes = new ArrayList<>();
	private Timer timer;
	private boolean wrapText = false;
	
	/**
	 * 
	 * Container for a shape to be drawn on the button.
	 * Contains shape, its color and width of the brush to draw.
	 *
	 */
	public static class AdditionalShape{
		private Shape shape;
		private Color color;
		private int width;
		
		/**
		 * Constructor.
		 * @param shape javax.swing.Shape object
		 * @param color color of the shape
		 * @param width width of the brush in pixels.
		 */
		AdditionalShape(Shape shape, Color color, int width){
			Objects.requireNonNull(shape);
			Objects.requireNonNull(color);
			if (width <=0 ) {
				throw new IllegalArgumentException("Negative or zero width of line specified");
			}
			
			this.shape = shape;
			this.color = color;
			this.width = width;
		}
	}
	
	/**
	 * Sets colors of the button.
	 * @param colorWhenReleased color when the button is not pressed.
	 * @param colorWhenPressed color when the button is pressed.
	 * @param borderColor color of the button's border.
	 */
	public void setColors(Color colorWhenReleased, Color colorWhenPressed, Color borderColor) {
		this.colorWhenReleased = currentColor = colorWhenReleased;
		this.colorWhenPressed = colorWhenPressed;
		this.borderColor = borderColor;
	}
	
	/**
	 * Sets text of the button, its color and font.
	 * @param text text to be drawn on the button.
	 * @param colorOfText color of the text.
	 * @param fontOfText font of the text.
	 */
	public void setText(String text, Color colorOfText, Font fontOfText) {
		this.text = text;
		this.colorOfText = colorOfText;
		this.fontOfText = currentFont = fontOfText;
	}
	
	/**
	 * Sets whether the text is to be wrapped.
	 * @param wrap <code>true</code> if needed to wrap
	 */
	public void setWrapText(boolean wrap) {
		wrapText = wrap;
	}
	
	/**
	 * Returns text of the button.
	 * @return text of the button.
	 */
	public String getText() {
		return text;
	}

	/**
	 * Constructor.
	 * @param width width of the button in pixels. 
	 * @param height height of the button. In case of the text wrapping the height may grow up according to required number of lines.
	 * @param radius radius of rounding.
	 */
	public RoundedButton(int width, int height, int radius) {
		if(width < 0 || height < 0 || radius < 0) {
			throw new IllegalArgumentException("Negative mesurements specified");
		}
		setSize(width, height);
		this.height = this.initHeight = height;
		this.width = width;
		this.radius = radius;
		
		this.addMouseListener(new RBMouseListener());
	}
	
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(width, height);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		adjustHeight(g2);
		paintButton(g2);
		paintText(g2);
		paintAdditionalShapes(g2);
	}
	
	/**
	 * Paints border of the button and fills its with color.
	 * @param g2 Graphics2D class object.
	 */
	private void paintButton(Graphics2D g2) {
		if(currentColor != null) {
			g2.setColor(currentColor);
			g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius*2, radius*2);
		}
		
		if(borderColor != null) {
			g2.setColor(borderColor);
			g2.drawRoundRect(0, 0, getWidth(), getHeight(), radius*2, radius*2);
			g2.drawLine(getWidth()-1, radius, getWidth()-1, getHeight() - radius);
			g2.drawLine(radius, getHeight() - 1, getWidth()-radius, getHeight() - 1);
		}		
	}
	
	/**
	 * Paints text on the button.
	 * @param g2 Graphics2D class object.
	 */
	private void paintText(Graphics2D g2) {
		if(text.isBlank()) {
			return;
		}
		
		g2.setFont(currentFont);
		g2.setColor(colorOfText);
			
		var context = g2.getFontRenderContext();
		var bounds = currentFont.getStringBounds(text, context);
		var metrix = currentFont.getLineMetrics(text, context);
		
		if(!wrapText) {
			g2.drawString(text, 
					(int) (getWidth() - bounds.getWidth()) / 2, 
					(int) (getHeight() + bounds.getHeight()) / 2 - metrix.getUnderlineOffset() / 2 - metrix.getDescent());
		}
		else  {
			var lines = getSubtextsOfSuitableSize(g2);
					
			for(int i = 0; i < lines.length; i++) {
				g2.drawString(lines[i], 
						0, 
						(int)(0+(bounds.getHeight() - metrix.getUnderlineOffset()/2)*(i+1) - metrix.getDescent()));				
			}
		}
	}
	
	/**
	 * Paints shapes on the button.
	 * @param g2 Graphics2D class object.
	 */
	private void paintAdditionalShapes(Graphics2D g2) {
		additionalShapes.forEach((addShape)->{
			g2.setColor(addShape.color);
			g2.setStroke(new BasicStroke(addShape.width));
			g2.draw(addShape.shape);
		});		
	}
	
	/**
	 * Divides text of the button into several substrings. Each substring has appropriate width to fit button width. 
	 * @param g2 Graphics2D class object.
	 * @return array of substrings.
	 */
	private String[] getSubtextsOfSuitableSize(Graphics2D g2) {
		
		String textToDivide = text;
		ArrayList<String> lines = new ArrayList<>();
		
		for(int i = textToDivide.length(); i >=0; i--) {
			var context = g2.getFontRenderContext();
			var bounds = currentFont.getStringBounds(textToDivide.substring(0, i), context);
			
			if(bounds.getWidth() < getWidth()) {
				lines.add(textToDivide.substring(0, i));
				if(i == textToDivide.length()) {
					break;
				}
				textToDivide = textToDivide.substring(i);
				i = textToDivide.length() + 1;
			}
		}
		
		return lines.toArray(new String[] {});		
	}
	
	/**
	 * Adjusts height of the button in case of multilines text.
	 * @param g2 Graphics2D class object
	 */
	private void adjustHeight(Graphics2D g2) {
		if(text.isEmpty() || !wrapText) {
			height = initHeight;
		}
		else {
			height = initHeight*getSubtextsOfSuitableSize(g2).length;
		}
		
		this.setBounds(getX(), getY(), getWidth(), height);
	}
	
	/**
     * Adds an <code>ActionListener</code> to the button.
     * @param l the <code>ActionListener</code> to be added
     */
    public void addActionListener(ActionListener l) {
    	actionListeners.add(l);
    }
    
    /**
     * Adds shapes to be drawn on the button.
     * @param addShape shape in the AdditionalShape wrapper
     */
    public void addAddtitionalShape(AdditionalShape addShape) {
    	Objects.requireNonNull(addShape);
    	additionalShapes.add(addShape);
    }
    
    /**
     * Presses the button and after 0.1 seconds releases it.
     */
    public void pressAndRelease() {
    	if(timer != null && timer.isRunning()) {
    		return;
    	}
    			
    	pressButton();
    	
    	timer = new Timer(100, (event)->{
    		releaseButton();
    		timer.stop();
    	});
    	timer.start();
    }
    
    /**
     * Redraws the button using another color of the background and the text of the reduced size. <br>
     * Then calls each action listeners.
     */
    private void pressButton() {
    	if(fontOfText != null) {
			currentFont = new Font(fontOfText.getFontName(), fontOfText.getStyle(), (int) (fontOfText.getSize() * (wrapText?1:0.8)));
		}
		currentColor = colorWhenPressed;
		repaint();
		actionListeners.forEach((l)->{
			l.actionPerformed(new ActionEvent(RoundedButton.this, ActionEvent.ACTION_FIRST, ""));
		});
    }
    
    /**
     * Redraws the button using initial background color and font size.
     */
    private void releaseButton() {
    	if(fontOfText != null) {
			currentFont = fontOfText;
		}
		currentColor = colorWhenReleased;
		repaint();
    }
	
    /**
     * 
     * Mouse Listener for rounded button.
     *
     */
	private class RBMouseListener extends MouseAdapter{

		@Override
		public void mousePressed(MouseEvent e) {
			pressButton();
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			releaseButton();
		}
	}
}
