package rbc.components;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.HashMap;

import javax.swing.*;

import rbc.utils.GBC;

/**
 * Implements keyboard of the calculator.
 *
 */
@SuppressWarnings("serial")
public class KeyBoard extends JPanel implements ICommonConstants {
	private static final int KEYBOARD_WIDTH = (int)(400*SIZE_SCALE);
	private static final int KEYBOARD_HEIGHT = (int)(520*SIZE_SCALE);
	/** font for x in the backspace button */
	private static final Font FONT_FOR_X = new Font("SensSerif", 0 , (int)(18*SIZE_SCALE));
	private static final int INSET_DISTANCE = 5;
	
	private RoundedButton[] printingButtons = new RoundedButton[18];
	private RoundedButton journalButton;
	private RoundedButton backspaceButton;
	private RoundedButton resultButton; 
	private RoundedButton clearButton;
	
	private HashMap<Character, RoundedButton> acceleratorsMap = new HashMap<>();
	
	/**
	 * Constructor.
	 */
	public KeyBoard() {
		setSize(KEYBOARD_WIDTH, KEYBOARD_HEIGHT);
		setLayout(new GridBagLayout());
		setBackground(WHITE_COLOR);
		
		addButtons();
	}
	
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(KEYBOARD_WIDTH, KEYBOARD_HEIGHT);
	}

	/**
	 * Returns array of printing buttons (when user press a printing button the character drawn on 
	 * it will be put to the end of the expression). 
	 * @return arrays of printing buttons
	 */
	public RoundedButton[] printingButtons() {
		return printingButtons;
	}
	
	/**
	 * Returns journal button (when user press it, the journal of previously calculated expressions will appear)
	 * @return journal button
	 */
	public RoundedButton journalButton() {
		return journalButton;
	}
	
	/**
	 * Returns backspace button (when user press it, the last printed sign in the expression will be removed)
	 * @return backspace button
	 */
	public RoundedButton backspaceButton() {
		return backspaceButton;
	}
	
	/**
	 * Returns result button (when user press it, the expression will be calculated)
	 * @return result button
	 */
	public RoundedButton resultButton() {
		return resultButton;
	}
	
	/**
	 * Returns clear button (when user press it, the expression will be cleared)
	 * @return clear button
	 */
	public RoundedButton clearButton() {
		return clearButton;
	}
	
	/**
	 * Returns accelerators map. Where key is some sign typed by user, value - associated RoundedButton
	 * @return map of accelerators
	 */
	public HashMap<Character, RoundedButton> accelerators(){
		return acceleratorsMap;
	}
	
	/**
	 * Adds buttons to the keyboard
	 */
	private void addButtons() {
		add(journalButton        = createJournalButton(),   new GBC(0,0).setInsets(INSET_DISTANCE));
		add(backspaceButton      = createBackspaceButton(), new GBC(3,0).setInsets(INSET_DISTANCE));
		int i = 0;
		add(printingButtons[i++] = createSimpleButton("(", GREEN_COLOR, GENERAL_FONT), new GBC(0,1).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton(")", GREEN_COLOR, GENERAL_FONT), new GBC(1,1).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("%", GREEN_COLOR, GENERAL_FONT), new GBC(2,1).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("/", GREEN_COLOR, GENERAL_FONT), new GBC(3,1).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("7", Color.BLACK, GENERAL_FONT), new GBC(0,2).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("8", Color.BLACK, GENERAL_FONT), new GBC(1,2).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("9", Color.BLACK, GENERAL_FONT), new GBC(2,2).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = replaceAccelerator('X', '*', createSimpleButton("X", GREEN_COLOR, GENERAL_FONT))
				                                                                     , new GBC(3,2).setInsets(INSET_DISTANCE)); 
		add(printingButtons[i++] = createSimpleButton("4", Color.BLACK, GENERAL_FONT), new GBC(0,3).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("5", Color.BLACK, GENERAL_FONT), new GBC(1,3).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("6", Color.BLACK, GENERAL_FONT), new GBC(2,3).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = replaceAccelerator(MINUS, '-', createSimpleButton(new String(new char[] {MINUS}), GREEN_COLOR, ENLAGED_FONT))
				                                                                     , new GBC(3,3).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("1", Color.BLACK, GENERAL_FONT), new GBC(0,4).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("2", Color.BLACK, GENERAL_FONT), new GBC(1,4).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("3", Color.BLACK, GENERAL_FONT), new GBC(2,4).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("+", GREEN_COLOR, ENLAGED_FONT), new GBC(3,4).setInsets(INSET_DISTANCE)); 
		add(clearButton          = addAccelerator('c', createSimpleButton("C", RED_COLOR, GENERAL_FONT))
				                                                                     , new GBC(0,5).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = createSimpleButton("0", Color.BLACK, GENERAL_FONT), new GBC(1,5).setInsets(INSET_DISTANCE));
		add(printingButtons[i++] = addAccelerator('.', createSimpleButton(",", Color.BLACK, ENLAGED_FONT))
				                                                                     , new GBC(2,5).setInsets(INSET_DISTANCE));
		add(resultButton = createResultButton()                                      , new GBC(3,5).setInsets(INSET_DISTANCE)); 
	}
	
	/**
	 * Adds new accelerator. 
	 * @param acc accelerator sign
	 * @param button associated RoundedButton
	 * @return pointer to the denoted button
	 */
	private RoundedButton addAccelerator(Character acc, RoundedButton button) {
		if(!acceleratorsMap.containsKey(acc)){
			acceleratorsMap.put(acc, button);
		}
		return button;
	}
	
	/**
	 * Replaces one accelerator sign with another
	 * @param oldAcc accelerator sign to be replaced
	 * @param newAcc replacing accelerator sign
	 * @param button associated RoundedButton
	 * @return pointer to the denoted button
	 */
	private RoundedButton replaceAccelerator(Character oldAcc, Character newAcc, RoundedButton button) {
		acceleratorsMap.remove(oldAcc);
		acceleratorsMap.put(newAcc, button);
		return button;
	}
	
	/**
	 * Creates button of grey color. Adds accelerator (first sign from the text of the button).
	 * @param text text of the button
	 * @param textColor color of the text 
	 * @param font font of the text
	 * @return created RoundedButton
	 */
	private RoundedButton createSimpleButton(String text, Color textColor, Font font) {
		var button = new RoundedButton((int)(76*SIZE_SCALE), (int)(64*SIZE_SCALE), (int)(30*SIZE_SCALE));
		button.setColors(GREY_COLOR, GREY_COLOR_PRESSED, GREY_COLOR_PRESSED);
		button.setText(text, textColor, font);
		if (!text.isBlank()) {
			addAccelerator(text.charAt(0), button);
		}
		return button;
	}
	
	/**
	 * Creates result button with text "=". Adds accelerators (Enter and =).
	 * @return created RoundedButton
	 */
	private RoundedButton createResultButton() {
		var button = new RoundedButton((int)(76*SIZE_SCALE), (int)(64*SIZE_SCALE), (int)(30*SIZE_SCALE));
		button.setColors(GREEN_COLOR, GREEN_COLOR_PRESSED, GREEN_COLOR_PRESSED);
		button.setText("=", Color.WHITE, ENLAGED_FONT);
		addAccelerator('=', button);
		addAccelerator((char)KeyEvent.VK_ENTER, button);
		
		return button;
	}
	
	/**
	 * Creates journal button with picture. Adds accelerators (j and J)
	 * @return created RoundedButton
	 */
	private RoundedButton createJournalButton() {
		var button = new RoundedButton((int)(64*SIZE_SCALE), (int)(64*SIZE_SCALE), (int)(30*SIZE_SCALE));
		button.setColors(WHITE_COLOR, WHITE_COLOR_PRESSED, WHITE_COLOR);
		int centerX = button.getX() + button.getWidth()/2;
		int centerY = button.getY() + button.getHeight()/2;
		
		var circle = new Ellipse2D.Double();
		circle.setFrameFromCenter(centerX, centerY, centerX + 20*SIZE_SCALE, centerY + 20*SIZE_SCALE);
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(circle, Color.BLACK, 1));
		
		var verLine = new Line2D.Double(centerX, centerY, centerX, centerY-15*SIZE_SCALE);
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(verLine, Color.BLACK, 2));
		
		var horLine = new Line2D.Double(centerX, centerY, centerX + 15*SIZE_SCALE, centerY);
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(horLine, Color.BLACK, 2));
		
		addAccelerator('j', button);
		addAccelerator('J', button);
		
		return button;
	}
	
	/**
	 * Creates backspace button with picture. Adds accelerator (backspace key)
	 * @return created RoundedButton
	 */
	private RoundedButton createBackspaceButton() {
		var button = new RoundedButton((int)(64*SIZE_SCALE), (int)(64*SIZE_SCALE), (int)(30*SIZE_SCALE));
		button.setColors(WHITE_COLOR, WHITE_COLOR_PRESSED, WHITE_COLOR);
		int centerX = button.getX() + button.getWidth()/2;
		int centerY = button.getY() + button.getHeight()/2;
		
		button.setText("x", GREEN_COLOR, FONT_FOR_X);
		
		var line = new Line2D.Double(centerX - (int)(12*SIZE_SCALE), 
				centerY - (int)(12*SIZE_SCALE), 
				centerX + (int)(12*SIZE_SCALE),
				centerY - (int)(12*SIZE_SCALE));
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(line, GREEN_COLOR, 2));
		
		line = new Line2D.Double(centerX + (int)(12*SIZE_SCALE), 
				centerY - (int)(12*SIZE_SCALE), 
				centerX + (int)(12*SIZE_SCALE),
				centerY + (int)(12*SIZE_SCALE));
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(line, GREEN_COLOR, 2));
		
		line = new Line2D.Double(centerX - (int)(12*SIZE_SCALE), 
				centerY + (int)(12*SIZE_SCALE), 
				centerX + (int)(12*SIZE_SCALE),
				centerY + (int)(12*SIZE_SCALE));
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(line, GREEN_COLOR, 2));
		
		line = new Line2D.Double(centerX - (int)(12*SIZE_SCALE), 
				centerY - (int)(12*SIZE_SCALE), 
				centerX - (int)(24*SIZE_SCALE),
				centerY);
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(line, GREEN_COLOR, 2));
		
		line = new Line2D.Double(centerX - (int)(24*SIZE_SCALE),
				centerY, 
				centerX - (int)(12*SIZE_SCALE),
				centerY + (int)(12*SIZE_SCALE));
		button.addAddtitionalShape(new RoundedButton.AdditionalShape(line, GREEN_COLOR, 2));
		
		addAccelerator((char)KeyEvent.VK_BACK_SPACE, button);
		
		return button;
	}
}
