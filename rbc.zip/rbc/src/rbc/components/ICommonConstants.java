package rbc.components;

import java.awt.Color;
import java.awt.Font;

/**
 * Contains common constants for classes in the package
 *
 */
interface ICommonConstants {
	static final char MINUS = '�';
	static final float SIZE_SCALE = 0.9f;
	static final Font GENERAL_FONT = new Font("SensSerif", 0 , (int)(28*SIZE_SCALE));
	static final Font ENLAGED_FONT = new Font("SensSerif", Font.BOLD , (int)(34*SIZE_SCALE));
	static final Color GREEN_COLOR = new Color(104, 179, 26);
	static final Color GREEN_COLOR_PRESSED = new Color(78, 153, 0);
	static final Color GREY_COLOR = new Color(245, 245, 245);
	static final Color GREY_COLOR_PRESSED = new Color(200, 200, 200);
	static final Color WHITE_COLOR = new Color(252, 252, 252);
	static final Color WHITE_COLOR_PRESSED = GREY_COLOR;
	static final Color RED_COLOR = new Color(219, 142, 124);
}
