package rbc;

import java.awt.*;
import java.awt.event.*;
import java.util.LinkedHashMap;
import java.util.prefs.Preferences;

import javax.swing.*;

import rbc.calculator.AdvancedExpressionCalculator;
import rbc.components.*;

/**
 * Enter point to the application.<br>
 * Creates and shows the main form of the application.
 *
 */
@SuppressWarnings("serial")
public class rbc extends JFrame {

	/**
	 * Main method of the application.
	 * @param args no arguments are applicable.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(()->{
			new rbc();
		});
	}

	private static final Font GENERAL_FONT = new Font("SensSerif", 0 , 20);
	
	private KeyBoard keyBoard;
	private JTextArea expressionContainer;
	private JTextField resultContainer;
	private LinkedHashMap<String, String> journal = new LinkedHashMap<>();
	
	/**
	 * Creates and shows the main form of the application.
	 */
	public rbc() {
		addComponents();
		addButtonsListeners();
		setFocusable(true);
		
		addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				var button = keyBoard.accelerators().get(e.getKeyChar());
				if (button != null) {
					button.pressAndRelease();
				}
			}
		});
		
		loadPreferences();
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				savePreferences();
			}
		});
		
		setTitle("rbc (rounded buttons calc)");
		setSize(keyBoard.getPreferredSize().width, keyBoard.getPreferredSize().height + 220);
		setResizable(false);	
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	/**
	 * Sets the denoted expression and calculates it.
	 * @param expression expression to set and calculate.
	 */
	public void setExpression(String expression) {
		expressionContainer.setText(expression);
		updateResult();
	}
	
	/**
	 * Clears the journal's records.
	 */
	public void clearJournal() {
		journal.clear();
	}
	
	/**
	 * Loads from the system start position of the application form and the journal's records.
	 */
	private void loadPreferences() {
		Preferences node = Preferences.userRoot().node("/java/portfolio/rbc");
		int x = node.getInt("x", 0);
		int y = node.getInt("y", 0);
		String journalRecords = node.get("journal", "");
		
		setLocation(x,y);
		if(!journalRecords.isEmpty()) {
			var records = journalRecords.split(":");
			for(int i = 0; i < records.length; i = i+2) {
				journal.put(records[i], records[i+1]);
			}
		}
	}
	
	/**
	 * Saves to the system start position of the application form and the journal's records.
	 */
	private void savePreferences() {
		Preferences node = Preferences.userRoot().node("/java/portfolio/rbc");
		node.putInt("x", getX());
		node.putInt("y", getY());
		
		StringBuilder sb = new StringBuilder();
		journal.forEach((expression, result)->{
			sb.append(expression+":");
			sb.append(result+":");
		});
		node.put("journal", sb.toString());
	}
	
	/**
	 * Adds GUI components to the application form.
	 */
	private void addComponents() {
		keyBoard = new KeyBoard();
		
		expressionContainer = new JTextArea(5,15);
		expressionContainer.setLineWrap(true);
		expressionContainer.setFont(GENERAL_FONT);
		expressionContainer.setEditable(false);
		JScrollPane expression_scroll = new JScrollPane(expressionContainer);
		
		resultContainer = new JTextField();
		resultContainer.setFont(GENERAL_FONT);
		resultContainer.setEditable(false);
		JScrollPane result_scroll = new JScrollPane(resultContainer);
		result_scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		
		add(keyBoard, BorderLayout.SOUTH);
		add(expression_scroll, BorderLayout.NORTH);
		add(result_scroll, BorderLayout.CENTER);
	}
	
	/**
	 * Adds commands to be performed on buttons' pressing.
	 */
	private void addButtonsListeners() {
		for(RoundedButton button: keyBoard.printingButtons()) {
			button.addActionListener((event)->{
				expressionContainer.append(button.getText());
				updateResult();
			});
		}
		
		keyBoard.backspaceButton().addActionListener((event)->{
			String expression = expressionContainer.getText();
			if(expression.isEmpty()) {
				return;
			}
			expressionContainer.setText(expression.substring(0, expression.length() - 1));
			updateResult();
		});
		
		keyBoard.clearButton().addActionListener((event)->{
			expressionContainer.setText("");
			updateResult();
		});
		
		keyBoard.resultButton().addActionListener(new ResultAction());
		
		keyBoard.journalButton().addActionListener((event)->{
			var dialog = new JournalDialog(this, "Journal", true, journal);
			dialog.setVisible(true);
		});
	}
	
	/**
	 * Calculates expression and sets result to the result field.
	 * @return String with error description if the expression has any errors.
	 */
	private String updateResult() {
		if(expressionContainer.getText().isEmpty()) {
			resultContainer.setText("");
			return "";
		}
		
		var calc = new AdvancedExpressionCalculator(expressionContainer.getText());
		calc.replaceSing('X', '*').replaceSing(KeyBoard.MINUS, '-').replaceSing(',', '.');
		var result = calc.calculate();
		
		if(result != null) {
			resultContainer.setText(result.stripTrailingZeros().toPlainString());
			return "";
		}		
		else {
			resultContainer.setText("");
			return calc.getError();
		}
	}
	
	/**
	 * Implements command when the "=" button is clicked.
	 * If the expression has an error, then shows the error. Otherwise updates the result field and puts expression and the
	 * result to the journal.
	 *
	 */
	private class ResultAction implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			String error = updateResult();
			if(!error.isEmpty()) {
				JDialog dialog = new JDialog(rbc.this, "Error in expression", true);
				dialog.setSize(200, 100);
				dialog.setBounds(rbc.this.getX(), rbc.this.getY(), rbc.this.getWidth(), 180);
				
				JLabel errorContainer = new JLabel();
				errorContainer.setText(error);
				errorContainer.setHorizontalAlignment(SwingConstants.CENTER);
				dialog.add(errorContainer);
				
				// close the dialog on Enter and Esc
				dialog.addKeyListener(new KeyAdapter() {

					@Override
					public void keyPressed(KeyEvent e) {
						if(e.getKeyChar() == KeyEvent.VK_ENTER || e.getKeyChar() == KeyEvent.VK_ESCAPE) {
							dialog.dispose();
						}
						
					}});
				
				dialog.setVisible(true);
			}
			else {
				rbc.this.journal.put(rbc.this.expressionContainer.getText(), rbc.this.resultContainer.getText());
				rbc.this.expressionContainer.setText(resultContainer.getText());
				rbc.this.resultContainer.setText("");
			}
		}
	}	
}
