package rbc.calculator;

import java.math.BigDecimal;

/**
 * Calculates sum of two numbers.
 *
 */
class AddOperation extends BinaryOperation {

	/**
	 *  Calculates sum of two numbers.
	 */
	@Override
	protected void execute() {
		if (percentForFirst) {
			first = first.divide(new BigDecimal(100));
		}

		if (percentForSecond) {
			result = first.divide(new BigDecimal(100)).multiply(second).add(first);
		} 
		else {
			result = first.add(second);
		}
	}
}
