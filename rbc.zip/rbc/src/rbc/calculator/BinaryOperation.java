package rbc.calculator;

import java.math.BigDecimal;

/**
 * Abstract class to all binary operations.
 *
 */
abstract class BinaryOperation {
	/** Precision of dividing in case of infinity digits after the decimal point. */
	static final int PRECISION = 20;
	/** first operand */
	BigDecimal first;
	/** second operand */
	BigDecimal second;
	/** indicates whether the percent sign is denoted after the first operand */
	boolean percentForFirst = false;
	/** indicates whether the percent sign is denoted after the second operand */
	boolean percentForSecond = false;
	/** contains result after the operation calculating */
	BigDecimal result;
	/** start index of the string representation of the operation in the expression */
	int startIndex;
	/** end index of the string representation of the operation in the expression */
	int endIndex;
	/** calculates the operation */
	abstract void execute();
}
