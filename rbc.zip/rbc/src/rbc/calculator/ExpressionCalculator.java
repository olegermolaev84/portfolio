package rbc.calculator;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Calculates the expression. Does not check the expression format.
 *
 */
class ExpressionCalculator {
	protected String expression;
	protected static Map<String, String> testCases = new LinkedHashMap<>();
	static
	{
		testCases.put("", "0");
		testCases.put("-525", "-525");
		testCases.put("555%", "5.55");
		
		testCases.put("10-6", "4");
		testCases.put("-6", "-6");
		testCases.put("5-2-3", "0");
		testCases.put("-2-3", "-5");
		testCases.put("5--4", "9");
		testCases.put("123-23-50", "50");
		testCases.put("200-30%", "140");
		testCases.put("200--30%", "260");
		testCases.put("200--30%-60", "200");
		testCases.put("1000%-5", "5");
		testCases.put("1000%-5-50%", "2.5");
		testCases.put("1028.56-5.-23.56", "1000");
		testCases.put("1028.56-5.-23.56--2500-10%", "3150");
		testCases.put("1028.56-5.-23.56--2500-10%--100%-.88", "6299.12");
		testCases.put("10.336699-0.000099", "10.3366");
		
		testCases.put("2+2", "4");
		testCases.put("20+2+44", "66");
		testCases.put("20+2+-44", "-22");
		testCases.put("50+10-3", "57");
		testCases.put("200.53-0.1+0.27", "200.7");
		testCases.put("8-2+3", "9");
		testCases.put("-45.63+0.37-10", "-55.26");
		testCases.put("100-30+100%", "140");
		testCases.put("500%+3", "8");
		testCases.put("500%+100%-50%", "5");
		testCases.put("10.23+0.17-1.4+100%", "18");
		
		testCases.put("2*2", "4");
		testCases.put("-2*-2", "4");
		testCases.put("-200.53*2+1.06", "-400");
		testCases.put("-200.53*2+1.06--500", "100");
		testCases.put("-200.53*2+1.06--250*2", "100");
		testCases.put("-200.53*2+2.12/2--250*2", "100");
		testCases.put("300+200-200.53*2+2.12/2--250*2", "600");
		testCases.put("300/3+200-200.53*2+2.12/2--250*2", "400");
		testCases.put("1/3", "0.33333333333333333333");
		testCases.put("2*2*2", "8");
		testCases.put("0.001*0.001","0.000001");
		testCases.put("1000000*1000000*1000000","1000000000000000000");
		testCases.put("0.001*0.001*0.001","0.000000001");
		testCases.put("0.001*0.001*0.001*0.001*0.001*0.001*0.001*0.001","0.000000000000000000000001");
		testCases.put("500%*200%", "10");
		testCases.put("500%*200", "1000");
		testCases.put("500*200%", "1000");
		testCases.put("500%/200%", "2.5");
		testCases.put("500%/200", "0.025");
		testCases.put("500/200%", "250");
		testCases.put("1000*-2","-2000");
		testCases.put("1000+1000*-2","-1000");
		testCases.put("1000/3+1000*-2","-1666.66666666666666666667");
		testCases.put("1000+1000*-2--100/.1","0");
		testCases.put("1000+1000*-2--100/0.1-500/-0.5","1000");
		testCases.put("-1000+1000+1000*-2--100/0.1-500/-0.5","0");
		
		testCases.put("(1+2)*(4-2)","6");
		testCases.put("(100-50+10.5)*(400%-25%)","181.5");
		testCases.put("100+(100-50+10.5)*(400%-25%)","281.5");
		testCases.put("100+3.333/3-(100-50+10.5)*(400%-25%)","-80.389");
		testCases.put("(1+2)","3");
		testCases.put("(-100%)","-1");
		testCases.put("((10+20)*3-10/2+(15+5)*3)+100*(12+8)","2145");
		testCases.put("((10+20)*3-10/(22/11*(100%))+(15+5)*3)+100%/1%*((1+(20/2-6))*(1+(1+(3-1))))","2145");
	}
	
	/**
	 * Constructor.
	 * @param expression expression to calculate.
	 */
	ExpressionCalculator(String expression){
		this.expression = expression;
	}
	
	/**
	 * Calculates the expression. It assumes the expression has correct format.
	 * @return result of the calculation in BigDecimal format.
	 */
	BigDecimal calculate() {
		//
		// if brackets are present, then first calculate expressions in them
		//
		int startPos;
		do {
			startPos = findBracketsWithoutNested();
			if (startPos != -1) {
				int endPos = posOfClosingBracket(startPos);
				
				String expressionWithinBrackets =
						expression.substring(startPos+1, endPos);
				
				String resultWithinBrackets =
						new ExpressionCalculator(expressionWithinBrackets).calculate().stripTrailingZeros().toPlainString();
				
				expression = expression.substring(0, startPos) 
						+ resultWithinBrackets
						+ (endPos == (expression.length() - 1)?"":expression.substring(endPos+1));
				
			}
		} while (startPos != -1);
		
		calculateOperationsOfTheSamePriority('*', '/');
		calculateOperationsOfTheSamePriority('+', '-');

		if (expression.isEmpty()) {
			return new BigDecimal(0);
		} 
		else if (expression.charAt(expression.length() - 1) == '%') {
			return new BigDecimal(expression.substring(0, expression.length() - 1)).divide(new BigDecimal(100));
		} 
		else {
			return new BigDecimal(expression);
		}
	}
	
	/**
	 * Searches the first occurrence of the brackets in the expression
	 * without nested brackets
	 * @return index of the founded opening bracket
	 */
	private int findBracketsWithoutNested() {
		for(int i = 0; i < expression.length(); i++) {
			if(expression.charAt(i) == '(') {
				if(isStartOfBracketsWithoutNested(i) != -1) {
					return i;
				}
			}
		}
		
		return -1;
	}
	
	/**
	 * Checks whether the brackets started at the denoted position have some nested brackets.
	 * @param posOfOpeningBracket index of opening bracket
	 * @return if the brackets do not have nested ones then returns index of the closing bracket, otherwise returns -1.
	 */
	private int isStartOfBracketsWithoutNested(int posOfOpeningBracket) {
		for(int i = posOfOpeningBracket + 1; i < expression.length(); i++) {
			if(expression.charAt(i) == ')') {
				return i;
			}
			else if(expression.charAt(i) == '(') {
				return -1;
			}
		}
		return -1;
	}
	
	/**
	 * Searches the first closing bracket starting from the denoted index in the expression.
	 * @param startPos - index in the expression from which the closing bracket is to be searched.
	 * @return index of the closing bracket or -1 if the closing bracket not found.
	 */
	private int posOfClosingBracket(int startPos) {
		for(int i = startPos + 1; i < expression.length(); i++) {
			if(expression.charAt(i) == ')') {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Searches all operations which denoted in arguments and sequently calculates them from left to right.
	 * Replaces operations in the expression with the result of the calculation. 
	 * @param oper1  character of the first operation
	 * @param oper2  character of the second operation
	 */
	private void calculateOperationsOfTheSamePriority(char oper1, char oper2) {
		while (true) {
			var operation1 = findBinaryOperation(oper1);
			var operation2 = findBinaryOperation(oper2);
			BinaryOperation operationToExecute = null;
			
			if(operation1 == null && operation2 == null) {
				return;
			}
			else if(operation1 == null) {
				operationToExecute = operation2;
			}
			else if(operation2 == null) {
				operationToExecute = operation1;
			}
			else if(operation1.startIndex < operation2.startIndex) {
				operationToExecute = operation1;
			}
			else {
				operationToExecute = operation2;
			}
			
			operationToExecute.execute();
			
			StringBuilder sb = new StringBuilder(expression.substring(0, operationToExecute.startIndex) 
			+ operationToExecute.result.toPlainString());
	
			if (operationToExecute.endIndex < (expression.length() - 1)) {
				sb.append(expression.substring(operationToExecute.endIndex + 1));
			}
			expression = sb.toString();
		}
	}
	
	/**
	 * Searches and parses the first occurrence of the denoted operation.
	 * @param operation character of the operation to search
	 * @return parsed operation in BinaryOperation format, if operation not found then returns <code>null</code>.
	 */
	private BinaryOperation findBinaryOperation(char operation) {
		if(expression.isEmpty()) {
			return null;
		}
		
		boolean unaryMinus = false;
		int startPosition = 0;
		int operationIndex;
		
		do {
			operationIndex = expression.indexOf(operation, startPosition);
			if (operationIndex == -1) {
				return null;
			}
			else if ((operation == '-' && operationIndex == 0)
					|| (operation == '-' && isOperationSing(expression.charAt(operationIndex-1)))){ // unary minus
				unaryMinus = true;
				startPosition = operationIndex+1;
			}
			else {
				unaryMinus = false;
			}
		} while(unaryMinus);
		
		BinaryOperation currentOperation;
		if(operation == '+') {
			currentOperation = new AddOperation();
		}
		else if (operation == '-'){
			currentOperation = new SubtractOperation();
		}
		else if (operation == '/'){
			currentOperation = new DivideOperation();
		}
		else {
			currentOperation = new MultiplyOperation();
		}
		getFirstOperand(operationIndex, currentOperation);
		getSecondOperand(operationIndex, currentOperation);
		return currentOperation;
	}
	
	/**
	 * Parses the left number from the denoted index of operation.
	 * @param operationIndex index of the operation in the expression.
	 * @param currentOperation pointer to the BinaryOperation object where the parsed number to be stored.
	 */
	private void getFirstOperand(int operationIndex, BinaryOperation currentOperation) {
		int i = operationIndex - 1;
		for(;i > 0; i--) {
			if(expression.charAt(i) == '-'
					&& (i == 0 || isOperationSing(expression.charAt(i-1)))) { // unary minus
				break;
			}
			else if (Character.isDigit(expression.charAt(i))) {
				continue;
			}
			else if (expression.charAt(i) == '.') {
				continue;
			}
			else if (expression.charAt(i) == '%') {
				currentOperation.percentForFirst = true;
				continue;
			}
			else {
				i++;
				break;
			}		
		}
		
		if(currentOperation.percentForFirst) {
			currentOperation.first = new BigDecimal(expression.substring(i, operationIndex-1));
		}
		else {
			currentOperation.first = new BigDecimal(expression.substring(i, operationIndex));
		}
		
		currentOperation.startIndex = i;
	}
	
	/**
	 * Parses the right number from the denoted index of operation.
	 * @param operationIndex index of the operation in the expression.
	 * @param currentOperation pointer to the BinaryOperation object where the parsed number to be stored.
	 */
	private void getSecondOperand(int operationIndex, BinaryOperation currentOperation) {
		int i = operationIndex + 1;
		for(; i < expression.length(); i++) {
			if(i == (operationIndex + 1) && expression.charAt(i) == '-') { // unary minus
				continue;
			}
			else if (Character.isDigit(expression.charAt(i))) {
				continue;
			}
			else if (expression.charAt(i) == '.') {
				continue;
			}
			else if (expression.charAt(i) == '%') {
				currentOperation.percentForSecond = true;
				break;
			}
			else {
				break;
			}
		}
		
		currentOperation.second = new BigDecimal(expression.substring(operationIndex + 1, i));
		if(currentOperation.percentForSecond) {
			currentOperation.endIndex = i;
		}
		else {
			currentOperation.endIndex = i - 1; 
		}
	}
	
	/**
	 * Checks whether the denoted character is binary operation sign.
	 * @param sign sign to check
	 * @return <code>true</code> if it is operation sign, otherwise returns <code>false</code>.
	 */
	protected boolean isOperationSing(char sign) {
		if(sign == '+' || sign == '-' || sign == '*' || sign == '/') {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Enter point to test the class.
	 * @param args no arguments are applicable.
	 */
	public static void main(String[] args) {
		testCases.forEach((expression, expectedResult)->{
			String result = new ExpressionCalculator(expression).calculate().stripTrailingZeros().toPlainString();
			System.out.println((result.equals(expectedResult)?"PASSED: ":"FAILED: ") 
					+ expression + " = " + result + " (expected: " + expectedResult + ")");
		});
	}
}
