package rbc.calculator;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Decorates ExpressionCalculator class. 
 * Additionally provides functionality of expression checking and functionality of replacing some characters.
 *
 */
public class AdvancedExpressionCalculator extends ExpressionCalculator {

	private String error;
	static
	{
		testCases.put("11.45+13.12.2+145.15", "More than one dots in number: 13.12.2");
		testCases.put("100+30%.01", "percent sign (%) at position 7 is not at the end of number");
		testCases.put("100+30%50", "percent sign (%) at position 7 is not at the end of number");
		testCases.put("100+%.01", "percent sign (%) at position 5 is not at the end of number");
		testCases.put(".1+.2", "0.3");
		testCases.put("-", "Unexpected sign at the begin of the expression");
		testCases.put("-+", "Unexpected sign at the begin of the expression");
		testCases.put("+352-52", "Unexpected sign at the begin of the expression");
		testCases.put("3+2-", "Unexpected sign after the sign at pos: 4");
		testCases.put("3+2-)", "Unexpected sign after the sign at pos: 4");
		testCases.put("3+2+-", "Unexpected sign after the sign at pos: 4");
		testCases.put("3+2+-)", "Unexpected sign after the sign at pos: 4");
		testCases.put("3+2+-(1%)", "4.99");
		testCases.put("3+2+-.1%", "4.995");
		testCases.put("3+2+(1%)", "5.01");
		testCases.put("3+2+.1%", "5.005");
		testCases.put("3(3+56)", "Unexpected sign before the opening bracket at pos: 2");
		testCases.put("(3+56)3", "Unexpected sign after the closing bracket at pos: 6");
		testCases.put("3)-56-3)", "Unexpected closing bracket at pos: 2");
		testCases.put("3*(1+2", "No closing bracket for opening bracket at pos: 3");
		testCases.put("3*(1+2)-(1+2*(15-6)+(13-5", "No closing bracket for opening bracket at pos: 9");
		testCases.put("3*(1+2)-(1+2*(15-6)+(13-5))))", "Number of closing brackets is not same as opening ones");
		testCases.put(".", "Incorrect number format at pos: 1");
		testCases.put("3+.", "Incorrect number format at pos: 3");
		testCases.put(".+3+.", "Incorrect number format at pos: 1");
		testCases.put("100+2-.+3", "Incorrect number format at pos: 7");
	}
	
	/**
	 * Returns error description if the expression has any errors. 
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * Constructor.
	 * @param expression expression to be checked and calculated.
	 */
	public AdvancedExpressionCalculator(String expression) {
		super(expression);
	}
	
	/**
	 * Investigates whether the expression has any errors.
	 * @return <code>true</code> if the expression has an error, otherwise returns <code>false</code>.
	 */
	private boolean checkExpression() {
		// What to check?
		// 1. expression should started with either unary minus followed by number
		//		or opening bracket
		//		or digit
		// 2. only zero or one dot (.) in each number
		// 3. if percent sign (%) is present it should be at the end of number
		// 4. after sing of operation should follow number or opening bracket
		//		or unary minus followed by number or opening bracket
		// 5. before opening bracket should be operation sign 
		//		or another opening bracket 
		//		or it should be the first in the expression
		// 6. after closing bracket should be operation sign
		//		or another closing bracket
		//		or it should be the last in the expression
		// 7. no closing brackets before any opening ones
		// 8. each opening bracket should have its closing pair
		// 9. Number of opening brackets should be the same as closing ones 
		// 10. before or after dot sign (.) should be digit
		
		if(expression.length() == 0) {
			return true;
		}
		
		//
		// CHECK 1. expression should started with either unary minus followed by number
		//		or opening bracket
		//		or digit (or dot)
		//
		boolean errorFound = false;
		if (expression.charAt(0) == '-') {
			if (expression.length() == 1) { // single minus in the expression
				errorFound = true;
			} 
			else if (!Character.isDigit(expression.charAt(1)) && expression.charAt(1) != '.') {
				errorFound = true;
			}
		}
		else if(expression.charAt(0) != '(' 
				&& !Character.isDigit(expression.charAt(0)) 
				&& expression.charAt(0) != '.'){
			errorFound = true;	
		}
		
		if(errorFound) {
			error = "Unexpected sign at the begin of the expression";
			return false;
		}
		
		//
		// CHECK 2. only zero or one dot (.) in each number
		//
		for(String number: getNumbers()) {
			if(number.split("\\.").length > 2) {
				error = "More than one dots in number: " + number;
				return false;
			}
		}
		
		//
		// CHECK 3. if percent sign (%) is present it should be at the end of number
		//
		int startPos = 0;
		int posOfPercent;
		while(startPos != expression.length() && (posOfPercent = expression.indexOf('%', startPos)) !=-1){
			if(posOfPercent < expression.length() - 1 
					&& (Character.isDigit(expression.charAt(posOfPercent + 1)) || expression.charAt(posOfPercent + 1) == '.')
					|| posOfPercent > 0
						&& (!Character.isDigit(expression.charAt(posOfPercent - 1)) && expression.charAt(posOfPercent - 1) != '.')) {
				error = "percent sign (%) at position " + (posOfPercent+1) + " is not at the end of number";
				return false;
			}
			
			startPos = posOfPercent + 1;
		}
		
		//
		// CHECK 4. after sign of operation should follow number or opening bracket
		//		or unary minus followed by number or opening bracket
		//
		errorFound = false;
		int i = 0;
		for(; i < expression.length(); i++) {
			if(isOperationSing(expression.charAt(i))) {
				if(i == expression.length() - 1) { // operation sign at the end of the expression is not allowed
					errorFound = true; break;
					
				}
				else if(expression.charAt(i+1) == '-') {
					// it must be unary minus
					if(i == expression.length() -2) { // unary minus at the end of the expression is not allowed
						errorFound = true; break;
					}
					else {
						if(!Character.isDigit(expression.charAt(i+2))
								&& expression.charAt(i+2) !='.'
								&& expression.charAt(i+2) != '(') {
							errorFound = true; break;
						}
					}
				}
				else if(!Character.isDigit(expression.charAt(i+1))
								&& expression.charAt(i+1) !='.'
								&& expression.charAt(i+1) != '(') {
					errorFound = true; break;
				}
			}
		}
		
		if(errorFound) {
			error = "Unexpected sign after the sign at pos: " + (i+1);
			return false;
		}
		
		//
		// CHECK 5. before opening bracket should be operation sign 
		//		or another opening bracket 
		//		or it should be the first in the expression
		//
		i = 0;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == '(' 
					&& i != 0 
					&& expression.charAt(i-1) != '(' 
					&& !isOperationSing(expression.charAt(i-1))) {
				error = "Unexpected sign before the opening bracket at pos: " + (i+1);
				return false;
			}
		}
		
		//
		// CHECK 6. after closing bracket should be operation sign
		//		or another closing bracket
		//		or it should be the last in the expression
		//
		i = 0;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == ')' 
					&& i != expression.length() - 1 
					&& expression.charAt(i+1) != ')' 
					&& !isOperationSing(expression.charAt(i+1))) {
				error = "Unexpected sign after the closing bracket at pos: " + (i+1);
				return false;
			}
		}
		
		//
		// 7. no closing brackets before any opening ones
		// 
		i = 0;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == ')') { 
				error = "Unexpected closing bracket at pos: " + (i+1);
				return false;
			}
			else if(expression.charAt(i) == '(') {
				break;
			}
		}
		
		//
		// 8. each opening bracket should have its closing pair
		//
		i = 0;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == '(' && !isOpeningHasClosingBracket(i)) { 
				error = "No closing bracket for opening bracket at pos: " + (i+1);
				return false;
			}
		}
		
		//
		// 9. Number of opening brackets should be the same as closing ones 
		//
		int opening = 0;
		int closing = 0;
		i = 0;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == '(') { 
				opening++;
			}
			else if(expression.charAt(i) == ')') { 
				closing++;
			}
		}
		
		if(opening != closing) {
			error = "Number of closing brackets is not same as opening ones";
			return false;
		}
		
		// 
		// 10. before or after dot sign (.) should be digit
		//
		i = 0;
		errorFound = false;
		for(; i < expression.length(); i++) {
			if(expression.charAt(i) == '.') {
				if (i == 0 && expression.length() == 1) {
					errorFound = true; break;
				}
				else if(i == expression.length() - 1) {
					if(!Character.isDigit(expression.charAt(i-1))) {
						errorFound = true; break;
					}
				}
				else if(i == 0) {
					if(!Character.isDigit(expression.charAt(i+1))) {
						errorFound = true; break;
					}
				}
				else {
					if(!Character.isDigit(expression.charAt(i-1)) && !Character.isDigit(expression.charAt(i+1))) {
						errorFound = true; break;
					}
				}
			}
		}
		
		if(errorFound) {
			error = "Incorrect number format at pos: " + (i+1);
			return false;
		}
		
		return true;
	} 
	
	/**
	 * Parses the expression and returns array of the numbers in it.
	 * @return array of numbers in string format.
	 */
	private String[] getNumbers(){
		ArrayList<String> result = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < expression.length(); i++) {
			if(Character.isDigit(expression.charAt(i)) 
					||expression.charAt(i) == '.') {
				sb.append(expression.charAt(i));
			}
			else if(sb.length() > 0) {
				result.add(sb.toString());
				sb = new StringBuilder();
			}
		}
		if(sb.length() > 0) {
			result.add(sb.toString());
		}
		return result.toArray(new String[0]);
	}
	
	/**
	 * Checks whether the opening bracket at the specified position has corresponding closing bracket.
	 * @param pos position of the opening bracket to check.
	 * @return <code>true</code> if the closing bracket found, otherwise <code>false</code>.
	 */
	private boolean isOpeningHasClosingBracket(int pos) {
		int depth = 1;
		for(int i = pos+1; i < expression.length(); i++) {
			if(expression.charAt(i) == '(') {
				depth++;
			}
			else if (expression.charAt(i) == ')') {
				depth--;
				if(depth == 0) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Replaces the given character in the expression with the required.
	 * @param oldChar character to be replaced.
	 * @param newChar replacing character.
	 * @return pointer to itself.
	 */
	public AdvancedExpressionCalculator replaceSing(char oldChar, char newChar) {
		expression = expression.replace(new String(new char[] {oldChar}), new String(new char[] {newChar}));
		return this;
	}
	
	/**
	 * Checks the expression, then calculates it.
	 */
	@Override
	public BigDecimal calculate() {
		if(checkExpression()) {
			try {
				return super.calculate();
			}
			catch(Exception e) {
				// it must be any unhandled error at the expression 
				error = "Error in expression";
				return null;
			}
		}
		else {
			return null;
		}
	}

	/**
	 * Enter point to test the class.
	 * @param args no arguments are applicable.
	 */
	public static void main(String[] args) {
		testCases.forEach((expression, expectedResult)->{
			String result_s;
			var calc = new AdvancedExpressionCalculator(expression);
			BigDecimal result = calc.calculate();
			if(result == null) {
				result_s = calc.getError();
			}
			else{
				result_s = result.stripTrailingZeros().toPlainString();
			}
			System.out.println((result_s.equals(expectedResult)?"PASSED: ":"FAILED: ") 
					+ expression + " = " + result_s + " (expected: " + expectedResult + ")");
		});
	}
}
