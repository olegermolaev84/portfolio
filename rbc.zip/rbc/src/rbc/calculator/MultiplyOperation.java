package rbc.calculator;

import java.math.BigDecimal;

/**
 * Multiplies two numbers.
 *
 */
class MultiplyOperation extends BinaryOperation {

	/**
	 * Multiplies two numbers.
	 */
	@Override
	void execute() {
		if (percentForFirst) {
			first = first.divide(new BigDecimal(100));
		}
		
		if (percentForSecond) {
			second = second.divide(new BigDecimal(100));
		}

		result = first.multiply(second);
	}
}
