package rbc.calculator;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Divides two numbers.
 *
 */
class DivideOperation extends BinaryOperation {
	
	/**
	 * Divides two numbers.
	 */
	@Override
	protected void execute() {
		if (percentForFirst) {
			first = first.divide(new BigDecimal(100));
		}
		
		if (percentForSecond) {
			second = second.divide(new BigDecimal(100));
		}

		try {
			result = first.divide(second);
		}
		catch(ArithmeticException e) {
			// infinity of digits after the "."
			result = first.divide(second, PRECISION, RoundingMode.HALF_UP);
		}
	}
}
