package rbc.calculator;

import java.math.BigDecimal;

/**
 * Subtracts two numbers.
 *
 */
class SubtractOperation extends BinaryOperation {

	/**
	 * Subtracts two numbers.
	 */
	@Override
	void execute() {
		if (percentForFirst) {
			first = first.divide(new BigDecimal(100));
		}

		if (percentForSecond) {
			result = first.divide(new BigDecimal(100))
					.multiply(new BigDecimal(100).subtract(second));
		} 
		else {
			result = first.subtract(second);
		}

	}
}
